﻿// assets/js/script.js
// =======================================================
// AI Tool Used: Claude AI for suggestions
// Group Members:
// 1. Hanbali (BI23110316)
// 2. Amri (BI23110304)
// =======================================================

document.addEventListener('DOMContentLoaded', function () {

    // ==================== Mobile Menu Toggle ====================
    const menuIcon = document.getElementById('menu-icon');
    const navLinks = document.getElementById('nav-links');

    if (menuIcon && navLinks) {
        menuIcon.addEventListener('click', function () {
            navLinks.classList.toggle('active');
        });

        // Close menu when clicking outside
        document.addEventListener('click', function (e) {
            if (!menuIcon.contains(e.target) && !navLinks.contains(e.target)) {
                navLinks.classList.remove('active');
            }
        });
    }

    // ==================== Form Validation ====================
    const forms = document.querySelectorAll('form');

    forms.forEach(form => {
        form.addEventListener('submit', function (e) {
            // Check for required checkboxes (recommend events)
            const checkboxGroups = form.querySelectorAll('input[type="checkbox"][required]');
            if (checkboxGroups.length > 0) {
                const checkboxName = checkboxGroups[0].name;
                const checkedBoxes = form.querySelectorAll(`input[name="${checkboxName}"]:checked`);

                if (checkedBoxes.length === 0) {
                    e.preventDefault();
                    alert('Please select at least one recommended event.');
                    return false;
                }
            }

            // Validate required fields
            const requiredFields = form.querySelectorAll('[required]');
            let isValid = true;

            requiredFields.forEach(field => {
                if (!field.value.trim() && field.type !== 'checkbox') {
                    isValid = false;
                    field.style.borderColor = '#e74c3c';
                } else {
                    field.style.borderColor = '#ddd';
                }
            });

            if (!isValid) {
                e.preventDefault();
                alert('Please fill in all required fields.');
                return false;
            }

            // Password confirmation validation
            const password = form.querySelector('input[name="password"]');
            const confirmPassword = form.querySelector('input[name="confirm_password"]');

            if (password && confirmPassword) {
                if (password.value !== confirmPassword.value) {
                    e.preventDefault();
                    alert('Passwords do not match!');
                    confirmPassword.style.borderColor = '#e74c3c';
                    password.style.borderColor = '#e74c3c';
                    return false;
                }
            }
        });
    });

    // ==================== Auto-hide Alerts ====================
    const alerts = document.querySelectorAll('.alert');

    alerts.forEach(alert => {
        setTimeout(() => {
            alert.style.transition = 'opacity 0.5s';
            alert.style.opacity = '0';
            setTimeout(() => alert.remove(), 500);
        }, 5000); // Hide after 5 seconds
    });

    // ==================== Confirm Delete Actions ====================
    const deleteButtons = document.querySelectorAll('.btn-delete, a[href*="delete"]');

    deleteButtons.forEach(button => {
        button.addEventListener('click', function (e) {
            if (!button.hasAttribute('onclick')) {
                if (!confirm('Are you sure you want to delete this?')) {
                    e.preventDefault();
                }
            }
        });
    });

    // ==================== Date Validation ====================
    const dateInputs = document.querySelectorAll('input[type="date"]');
    const today = new Date().toISOString().split('T')[0];

    dateInputs.forEach(input => {
        // Set minimum date to today if not already set
        if (!input.hasAttribute('min')) {
            input.setAttribute('min', today);
        }

        // Validate on change
        input.addEventListener('change', function () {
            if (this.value < today) {
                alert('Please select a future date.');
                this.value = '';
            }
        });
    });

    // Registration close date validation
    const eventDateInput = document.querySelector('input[name="event_date"]');
    const regCloseDateInput = document.querySelector('input[name="registration_close_date"]');

    if (eventDateInput && regCloseDateInput) {
        regCloseDateInput.addEventListener('change', function () {
            if (eventDateInput.value && this.value > eventDateInput.value) {
                alert('Registration close date must be before the event date.');
                this.value = '';
            }
        });
    }

    // ==================== Image Preview ====================
    const fileInputs = document.querySelectorAll('input[type="file"][accept*="image"]');

    fileInputs.forEach(input => {
        input.addEventListener('change', function (e) {
            const file = e.target.files[0];
            if (file) {
                // Check file size (max 5MB)
                if (file.size > 5 * 1024 * 1024) {
                    alert('File size must be less than 5MB');
                    this.value = '';
                    return;
                }

                // Check file type
                const validTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif'];
                if (!validTypes.includes(file.type)) {
                    alert('Please select a valid image file (JPG, PNG, or GIF)');
                    this.value = '';
                    return;
                }

                console.log('Image selected:', file.name);
            }
        });
    });

    // ==================== Smooth Scroll ====================
    const smoothScrollLinks = document.querySelectorAll('a[href^="#"]');

    smoothScrollLinks.forEach(link => {
        link.addEventListener('click', function (e) {
            const targetId = this.getAttribute('href');
            if (targetId !== '#' && targetId !== '') {
                const targetElement = document.querySelector(targetId);
                if (targetElement) {
                    e.preventDefault();
                    targetElement.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
            }
        });
    });

    // ==================== Table Row Highlighting ====================
    const tableRows = document.querySelectorAll('.data-table tbody tr');

    tableRows.forEach(row => {
        row.addEventListener('mouseenter', function () {
            this.style.backgroundColor = '#f0f8ff';
        });

        row.addEventListener('mouseleave', function () {
            this.style.backgroundColor = '';
        });
    });

    // ==================== Loading Indicator for Forms ====================
    forms.forEach(form => {
        form.addEventListener('submit', function () {
            const submitBtn = form.querySelector('button[type="submit"]');
            if (submitBtn) {
                submitBtn.disabled = true;
                submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Processing...';
            }
        });
    });

    console.log('✅ CEMS JavaScript loaded successfully!');
});