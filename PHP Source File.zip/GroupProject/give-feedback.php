<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/controllers/FeedbackController.php';
$controller = new FeedbackController();
$controller->create();
?>