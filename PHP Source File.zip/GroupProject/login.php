<?php
// login.php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/controllers/AuthController.php';

// Redirect if already logged in
if (isLoggedIn()) {
    redirect('/dashboard.php');
}

$controller = new AuthController();
$controller->login();
?>