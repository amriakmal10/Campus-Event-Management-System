<?php
// dashboard.php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/controllers/DashboardController.php';

$controller = new DashboardController();
$controller->index();
?>