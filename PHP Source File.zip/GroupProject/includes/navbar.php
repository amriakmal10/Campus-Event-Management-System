<?php
// includes/navbar.php

// Get unread notification count if logged in
$unreadNotifications = 0;
if (isLoggedIn()) {
    require_once __DIR__ . '/../models/Notification.php';
    $tempConn = getDBConnection();
    $notifModel = new Notification($tempConn);
    $unreadNotifications = $notifModel->getUnreadCount($_SESSION['user_id']);
    $tempConn->close();
}
?>
<nav class="navbar">
    <div class="nav-container">
        <a href="<?php echo BASE_URL; ?>/index.php" class="brand" title="UMS Event Registry">UMSER</a>
        <div class="menu-icon" id="menu-icon">
            <i class="fas fa-bars"></i>
        </div>
        <ul class="nav-links" id="nav-links">
            <li><a href="<?php echo BASE_URL; ?>/index.php">Home</a></li>
            <?php if (isLoggedIn()): ?>
                <li><a href="<?php echo BASE_URL; ?>/dashboard.php">Dashboard</a></li>
                
                <!-- ADMIN MENU -->
                <?php if (isAdmin()): ?>
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle">
                            <i class="fas fa-user-shield"></i> Admin <i class="fas fa-chevron-down"></i>
                        </a>
                        <ul class="dropdown-menu">
                            <li><a href="<?php echo BASE_URL; ?>/admin-dashboard.php"><i class="fas fa-tachometer-alt"></i> Admin Dashboard</a></li>
                            <li><a href="<?php echo BASE_URL; ?>/admin-users.php"><i class="fas fa-users"></i> Manage Users</a></li>
                            <li><a href="<?php echo BASE_URL; ?>/admin-events.php"><i class="fas fa-calendar"></i> Manage Events</a></li>
                            <li><a href="<?php echo BASE_URL; ?>/admin-statistics.php"><i class="fas fa-chart-bar"></i> Statistics</a></li>
                        </ul>
                    </li>
                <?php endif; ?>
                
                <li>
                    <a href="<?php echo BASE_URL; ?>/notifications.php" style="position: relative; display: inline-block;">
                        <i class="fas fa-bell"></i> Notifications
                        <?php if ($unreadNotifications > 0): ?>
                            <span class="notification-badge"><?php echo $unreadNotifications; ?></span>
                        <?php endif; ?>
                    </a>
                </li>
                <li><a href="<?php echo BASE_URL; ?>/logout.php">Logout (<?php echo h($_SESSION['fullname']); ?>)</a></li>
            <?php else: ?>
                <li><a href="<?php echo BASE_URL; ?>/register.php">Register</a></li>
                <li><a href="<?php echo BASE_URL; ?>/login.php">Login</a></li>
            <?php endif; ?>
        </ul>
    </div>
</nav>