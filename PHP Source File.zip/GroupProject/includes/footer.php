<?php
// includes/footer.php
?>
<footer class="site-footer">
    <div class="footer-content">
        <p>&copy; <?php echo date('Y'); ?> UMS Event Registry. All rights reserved.</p>
        <p>Group Project - Developed by Hanbali (BI23110316) & Amri (BI23110304)</p>
    </div>
</footer>

<script src="<?php echo BASE_PATH_JS; ?>script.js"></script>
</body>
</html>