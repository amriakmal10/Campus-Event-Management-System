<?php
// edit-event.php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/controllers/EventController.php';

requireLogin();

if (!isset($_GET['id'])) {
    redirect('/dashboard.php?view=my-events');
}

$controller = new EventController();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $controller->update((int)$_GET['id']);
} else {
    $controller->showEdit((int)$_GET['id']);
}
?>