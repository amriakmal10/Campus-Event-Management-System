<?php
// event.php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/controllers/EventController.php';

if (!isset($_GET['id'])) {
    redirect('/index.php');
}

$controller = new EventController();
$controller->view((int)$_GET['id']);
?>