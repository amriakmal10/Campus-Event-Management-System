<?php
// create-event.php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/controllers/EventController.php';

requireLogin();

$controller = new EventController();
$controller->create();
?>