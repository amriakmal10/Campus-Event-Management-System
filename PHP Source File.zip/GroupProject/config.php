<?php
// config.php
// =======================================================
// AI Tool Used: Claude AI for MVC structure guidance
// Group Members:
// 1. Hanbali (BI23110316)
// 2. Amri (BI23110304)
// =======================================================

session_start();

// Database configuration
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'cems_project');

// Project path - UPDATED FOR YOUR PATH
$projectFolder = '/cems/GroupProject';  
$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? "https://" : "http://";
$host = $_SERVER['HTTP_HOST'];

define('BASE_URL', $protocol . $host . $projectFolder);
define('ROOT_PATH', $_SERVER['DOCUMENT_ROOT'] . $projectFolder);

// Asset paths
define('BASE_PATH_ASSETS', BASE_URL . '/assets');
define('BASE_PATH_CSS', BASE_PATH_ASSETS . '/css/');
define('BASE_PATH_JS', BASE_PATH_ASSETS . '/js/');
define('BASE_PATH_IMG', BASE_PATH_ASSETS . '/img/');
define('BASE_PATH_UPLOADS', BASE_URL . '/uploads/');

// Database connection
function getDBConnection() {
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    
    if ($conn->connect_error) {
        die("Database connection failed: " . $conn->connect_error);
    }
    
    $conn->set_charset("utf8");
    return $conn;
}

// Helper functions
function h($str) {
    return htmlspecialchars($str ?? '', ENT_QUOTES, 'UTF-8');
}

function redirect($url) {
    header("Location: " . BASE_URL . $url);
    exit;
}

function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

function requireLogin() {
    if (!isLoggedIn()) {
        $_SESSION['error'] = "Please login to access this page.";
        redirect('/login.php');
    }
    blockSuspended();
}

function getCurrentUser() {
    if (!isLoggedIn()) {
        return null;
    }
    
    $conn = getDBConnection();
    $stmt = $conn->prepare("SELECT * FROM users WHERE user_id = ?");
    $stmt->bind_param("i", $_SESSION['user_id']);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();
    $stmt->close();
    $conn->close();
    
    return $user;
}

// Check if user is admin
function isAdmin() {
    if (!isLoggedIn()) {
        return false;
    }
    
    $user = getCurrentUser();
    return isset($user['is_admin']) && $user['is_admin'] == 1;
}

// Require admin access
function requireAdmin() {
    if (!isAdmin()) {
        $_SESSION['error'] = "Access denied. Admin privileges required.";
        redirect('/dashboard.php');
    }
}

// Check if user is suspended
function isSuspended() {
    if (!isLoggedIn()) {
        return false;
    }
    
    $user = getCurrentUser();
    return isset($user['is_suspended']) && $user['is_suspended'] == 1;
}

// Block suspended users
function blockSuspended() {
    if (isSuspended()) {
        session_destroy();
        $_SESSION['error'] = "Your account has been suspended. Please contact admin.";
        redirect('/login.php');
    }
}

// Error handling
error_reporting(E_ALL);
ini_set('display_errors', 1);
?>