<?php
// views/admin/statistics.php
$pageTitle = "Statistics & Reports";
?>

<?php include __DIR__ . '/../../includes/header.php'; ?>
<?php include __DIR__ . '/../../includes/navbar.php'; ?>

<main class="container">
    <div class="page-header">
        <h2><i class="fas fa-chart-bar"></i> Statistics & Reports</h2>
        <a href="<?php echo BASE_URL; ?>/admin-dashboard.php" class="btn btn-outline">
            <i class="fas fa-arrow-left"></i> Back to Dashboard
        </a>
    </div>
    
    <!-- Overview Stats -->
    <div class="stats-overview">
        <div class="stat-box">
            <i class="fas fa-users"></i>
            <h3><?php echo $stats['total_users']; ?></h3>
            <p>Total Users</p>
        </div>
        
        <div class="stat-box">
            <i class="fas fa-calendar"></i>
            <h3><?php echo $stats['total_events']; ?></h3>
            <p>Total Events</p>
        </div>
        
        <div class="stat-box">
            <i class="fas fa-ticket-alt"></i>
            <h3><?php echo $stats['total_registrations']; ?></h3>
            <p>Total Registrations</p>
        </div>
        
        <div class="stat-box">
            <i class="fas fa-chart-line"></i>
            <h3><?php echo $stats['total_events'] > 0 ? round($stats['total_registrations'] / $stats['total_events'], 1) : 0; ?></h3>
            <p>Avg. Participants/Event</p>
        </div>
    </div>
    
    <!-- Detailed Charts -->
    <div class="statistics-grid">
        <!-- Events by Category -->
        <div class="stat-card">
            <h3><i class="fas fa-chart-pie"></i> Events by Category</h3>
            <div class="chart-list">
                <?php if (!empty($stats['events_by_category'])): ?>
                    <?php foreach ($stats['events_by_category'] as $category => $count): ?>
                        <div class="chart-item">
                            <span class="chart-label"><?php echo h($category); ?></span>
                            <div class="chart-bar">
                                <div class="chart-bar-fill" style="width: <?php echo ($count / max($stats['events_by_category'])) * 100; ?>%; background: #3498db;"></div>
                            </div>
                            <span class="chart-value"><?php echo $count; ?></span>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p>No events data available.</p>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- Users by Category -->
        <div class="stat-card">
            <h3><i class="fas fa-users"></i> Users by Category</h3>
            <div class="chart-list">
                <?php if (!empty($stats['users_by_category'])): ?>
                    <?php foreach ($stats['users_by_category'] as $category => $count): ?>
                        <div class="chart-item">
                            <span class="chart-label"><?php echo ucfirst(h($category)); ?></span>
                            <div class="chart-bar">
                                <div class="chart-bar-fill" style="width: <?php echo ($count / max($stats['users_by_category'])) * 100; ?>%; background: #2ecc71;"></div>
                            </div>
                            <span class="chart-value"><?php echo $count; ?></span>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p>No users data available.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <!-- Recent Events Table -->
    <div class="stat-card">
        <h3><i class="fas fa-calendar-alt"></i> Recent Events</h3>
        <?php if (!empty($stats['recent_events'])): ?>
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Event Name</th>
                        <th>Date</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($stats['recent_events'] as $event): ?>
                        <tr>
                            <td><?php echo h($event['event_name']); ?></td>
                            <td><?php echo date('d M Y', strtotime($event['event_date'])); ?></td>
                            <td><span class="badge badge-<?php echo $event['status']; ?>"><?php echo ucfirst($event['status']); ?></span></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>No recent events.</p>
        <?php endif; ?>
    </div>
    
    <!-- Print Report Button -->
    <div class="report-actions">
        <button onclick="window.print()" class="btn btn-primary">
            <i class="fas fa-print"></i> Print Report
        </button>
        <button onclick="alert('CSV Export - To be implemented')" class="btn btn-outline">
            <i class="fas fa-download"></i> Export to CSV
        </button>
    </div>
</main>

<?php include __DIR__ . '/../../includes/footer.php'; ?>