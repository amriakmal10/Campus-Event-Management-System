<?php
// views/admin/dashboard.php
$pageTitle = "Admin Dashboard";
?>

<?php include __DIR__ . '/../../includes/header.php'; ?>
<?php include __DIR__ . '/../../includes/navbar.php'; ?>

<main class="container">
    <div class="admin-header">
        <h1><i class="fas fa-user-shield"></i> Admin Dashboard</h1>
        <p>Welcome, <?php echo h($_SESSION['fullname']); ?>! Manage your system from here.</p>
    </div>
    
    <?php if (isset($_SESSION['success'])): ?>
        <div class="alert alert-success">
            <?php echo h($_SESSION['success']); unset($_SESSION['success']); ?>
        </div>
    <?php endif; ?>
    
    <!-- Statistics Cards -->
    <div class="admin-stats-grid">
        <div class="admin-stat-card">
            <div class="stat-icon" style="background: #3498db;">
                <i class="fas fa-users"></i>
            </div>
            <div class="stat-info">
                <h3><?php echo $stats['total_users']; ?></h3>
                <p>Total Users</p>
            </div>
        </div>
        
        <div class="admin-stat-card">
            <div class="stat-icon" style="background: #2ecc71;">
                <i class="fas fa-calendar"></i>
            </div>
            <div class="stat-info">
                <h3><?php echo $stats['total_events']; ?></h3>
                <p>Total Events</p>
            </div>
        </div>
        
        <div class="admin-stat-card">
            <div class="stat-icon" style="background: #e74c3c;">
                <i class="fas fa-ticket-alt"></i>
            </div>
            <div class="stat-info">
                <h3><?php echo $stats['total_registrations']; ?></h3>
                <p>Total Registrations</p>
            </div>
        </div>
    </div>
    
    <!-- Quick Actions -->
    <div class="admin-quick-actions">
        <h2>Quick Actions</h2>
        <div class="quick-action-buttons">
            <a href="<?php echo BASE_URL; ?>/admin-users.php" class="btn btn-primary">
                <i class="fas fa-users"></i> Manage Users
            </a>
            <a href="<?php echo BASE_URL; ?>/admin-events.php" class="btn btn-primary">
                <i class="fas fa-calendar"></i> Manage Events
            </a>
            <a href="<?php echo BASE_URL; ?>/admin-statistics.php" class="btn btn-primary">
                <i class="fas fa-chart-bar"></i> View Statistics
            </a>
            <a href="<?php echo BASE_URL; ?>/create-event.php" class="btn btn-outline">
                <i class="fas fa-plus"></i> Create Event
            </a>
        </div>
    </div>
    
    <!-- Charts Section -->
    <div class="admin-charts">
        <div class="chart-container">
            <h3>Events by Category</h3>
            <div class="chart-list">
                <?php foreach ($stats['events_by_category'] as $category => $count): ?>
                    <div class="chart-item">
                        <span class="chart-label"><?php echo h($category); ?></span>
                        <div class="chart-bar">
                            <div class="chart-bar-fill" style="width: <?php echo ($count / max($stats['events_by_category'])) * 100; ?>%;"></div>
                        </div>
                        <span class="chart-value"><?php echo $count; ?></span>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
        
        <div class="chart-container">
            <h3>Users by Category</h3>
            <div class="chart-list">
                <?php foreach ($stats['users_by_category'] as $category => $count): ?>
                    <div class="chart-item">
                        <span class="chart-label"><?php echo ucfirst(h($category)); ?></span>
                        <div class="chart-bar">
                            <div class="chart-bar-fill" style="width: <?php echo ($count / max($stats['users_by_category'])) * 100; ?>%;"></div>
                        </div>
                        <span class="chart-value"><?php echo $count; ?></span>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
    
    <!-- Recent Events -->
    <div class="admin-recent">
        <h3>Recent Events</h3>
        <table class="data-table">
            <thead>
                <tr>
                    <th>Event Name</th>
                    <th>Date</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($stats['recent_events'] as $event): ?>
                    <tr>
                        <td><?php echo h($event['event_name']); ?></td>
                        <td><?php echo date('d M Y', strtotime($event['event_date'])); ?></td>
                        <td><span class="badge badge-<?php echo $event['status']; ?>"><?php echo ucfirst($event['status']); ?></span></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</main>

<?php include __DIR__ . '/../../includes/footer.php'; ?>