<?php
// views/admin/events.php
$pageTitle = "Manage Events";
?>

<?php include __DIR__ . '/../../includes/header.php'; ?>
<?php include __DIR__ . '/../../includes/navbar.php'; ?>

<main class="container">
    <div class="page-header">
        <h2><i class="fas fa-calendar"></i> Manage Events</h2>
        <div>
            <a href="<?php echo BASE_URL; ?>/create-event.php" class="btn btn-primary">
                <i class="fas fa-plus"></i> Create Event
            </a>
            <a href="<?php echo BASE_URL; ?>/admin-dashboard.php" class="btn btn-outline">
                <i class="fas fa-arrow-left"></i> Back to Dashboard
            </a>
        </div>
    </div>
    
    <?php if (isset($_SESSION['success'])): ?>
        <div class="alert alert-success">
            <?php echo h($_SESSION['success']); unset($_SESSION['success']); ?>
        </div>
    <?php endif; ?>
    
    <?php if (isset($_SESSION['error'])): ?>
        <div class="alert alert-error">
            <?php echo h($_SESSION['error']); unset($_SESSION['error']); ?>
        </div>
    <?php endif; ?>
    
    <div class="admin-table-container">
        <table class="data-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Event Name</th>
                    <th>Category</th>
                    <th>Organizer</th>
                    <th>Creator</th>
                    <th>Date</th>
                    <th>Participants</th>
                    <th>Status</th>
                    <th>Highlighted</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($events as $event): ?>
                    <tr>
                        <td><?php echo $event['event_id']; ?></td>
                        <td><?php echo h($event['event_name']); ?></td>
                        <td><span class="badge badge-info"><?php echo h($event['category']); ?></span></td>
                        <td><?php echo h($event['organizer']); ?></td>
                        <td><?php echo h($event['creator_name']); ?></td>
                        <td><?php echo date('d M Y', strtotime($event['event_date'])); ?></td>
                        <td><?php echo $event['participant_count']; ?><?php echo $event['max_participants'] ? '/' . $event['max_participants'] : ''; ?></td>
                        <td><span class="badge badge-<?php echo $event['status']; ?>"><?php echo ucfirst($event['status']); ?></span></td>
                        <td>
                            <?php if ($event['is_highlighted']): ?>
                                <span class="badge" style="background: #f39c12;"><i class="fas fa-star"></i> Featured</span>
                            <?php else: ?>
                                <span class="badge" style="background: #95a5a6;">Normal</span>
                            <?php endif; ?>
                        </td>
                        <td class="action-buttons">
                            <a href="<?php echo BASE_URL; ?>/event.php?id=<?php echo $event['event_id']; ?>" 
                               class="btn-small btn-view">
                                <i class="fas fa-eye"></i> View
                            </a>
                            
                            <!-- Highlight/Unhighlight -->
                            <?php if ($event['is_highlighted']): ?>
                                <a href="<?php echo BASE_URL; ?>/admin-unhighlight-event.php?id=<?php echo $event['event_id']; ?>" 
                                   class="btn-small" style="background: #95a5a6;">
                                    <i class="fas fa-star-half"></i> Unhighlight
                                </a>
                            <?php else: ?>
                                <a href="<?php echo BASE_URL; ?>/admin-highlight-event.php?id=<?php echo $event['event_id']; ?>" 
                                   class="btn-small" style="background: #f39c12;">
                                    <i class="fas fa-star"></i> Highlight
                                </a>
                            <?php endif; ?>
                            
                            <!-- Archive -->
                            <?php if ($event['status'] != 'completed'): ?>
                                <a href="<?php echo BASE_URL; ?>/admin-archive-event.php?id=<?php echo $event['event_id']; ?>" 
                                   class="btn-small" style="background: #3498db;"
                                   onclick="return confirm('Archive this event?');">
                                    <i class="fas fa-archive"></i> Archive
                                </a>
                            <?php endif; ?>
                            
                            <!-- Delete -->
                            <a href="<?php echo BASE_URL; ?>/admin-delete-event.php?id=<?php echo $event['event_id']; ?>" 
                               class="btn-small btn-delete"
                               onclick="return confirm('Delete this event? This action cannot be undone!');">
                                <i class="fas fa-trash"></i> Delete
                            </a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</main>

<?php include __DIR__ . '/../../includes/footer.php'; ?>