<?php
// views/admin/users.php
$pageTitle = "Manage Users";
?>

<?php include __DIR__ . '/../../includes/header.php'; ?>
<?php include __DIR__ . '/../../includes/navbar.php'; ?>

<main class="container">
    <div class="page-header">
        <h2><i class="fas fa-users"></i> Manage Users</h2>
        <a href="<?php echo BASE_URL; ?>/admin-dashboard.php" class="btn btn-outline">
            <i class="fas fa-arrow-left"></i> Back to Dashboard
        </a>
    </div>
    
    <?php if (isset($_SESSION['success'])): ?>
        <div class="alert alert-success">
            <?php echo h($_SESSION['success']); unset($_SESSION['success']); ?>
        </div>
    <?php endif; ?>
    
    <?php if (isset($_SESSION['error'])): ?>
        <div class="alert alert-error">
            <?php echo h($_SESSION['error']); unset($_SESSION['error']); ?>
        </div>
    <?php endif; ?>
    
    <div class="admin-table-container">
        <table class="data-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Category</th>
                    <th>Organization</th>
                    <th>Status</th>
                    <th>Role</th>
                    <th>Joined</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($users as $user): ?>
                    <tr>
                        <td><?php echo $user['user_id']; ?></td>
                        <td><?php echo h($user['fullname']); ?></td>
                        <td><?php echo h($user['email']); ?></td>
                        <td><span class="badge badge-info"><?php echo ucfirst(h($user['category'])); ?></span></td>
                        <td><?php echo h($user['organization']); ?></td>
                        <td>
                            <?php if ($user['is_suspended']): ?>
                                <span class="badge badge-danger">Suspended</span>
                            <?php else: ?>
                                <span class="badge badge-success">Active</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if ($user['is_admin']): ?>
                                <span class="badge" style="background: #9b59b6;">Admin</span>
                            <?php else: ?>
                                <span class="badge" style="background: #95a5a6;">User</span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo date('d M Y', strtotime($user['created_at'])); ?></td>
                        <td class="action-buttons">
                            <?php if ($user['user_id'] != $_SESSION['user_id']): ?>
                                <!-- Admin Promotion -->
                                <?php if ($user['is_admin']): ?>
                                    <a href="<?php echo BASE_URL; ?>/admin-demote-user.php?id=<?php echo $user['user_id']; ?>" 
                                       class="btn-small" style="background: #95a5a6;"
                                       onclick="return confirm('Demote this admin to user?');">
                                        <i class="fas fa-user-minus"></i> Demote
                                    </a>
                                <?php else: ?>
                                    <a href="<?php echo BASE_URL; ?>/admin-promote-user.php?id=<?php echo $user['user_id']; ?>" 
                                       class="btn-small" style="background: #9b59b6;"
                                       onclick="return confirm('Promote this user to admin?');">
                                        <i class="fas fa-user-plus"></i> Promote
                                    </a>
                                <?php endif; ?>
                                
                                <!-- Suspension -->
                                <?php if ($user['is_suspended']): ?>
                                    <a href="<?php echo BASE_URL; ?>/admin-unsuspend-user.php?id=<?php echo $user['user_id']; ?>" 
                                       class="btn-small" style="background: #2ecc71;">
                                        <i class="fas fa-check"></i> Unsuspend
                                    </a>
                                <?php else: ?>
                                    <a href="<?php echo BASE_URL; ?>/admin-suspend-user.php?id=<?php echo $user['user_id']; ?>" 
                                       class="btn-small" style="background: #f39c12;"
                                       onclick="return confirm('Suspend this user?');">
                                        <i class="fas fa-ban"></i> Suspend
                                    </a>
                                <?php endif; ?>
                                
                                <!-- Delete -->
                                <a href="<?php echo BASE_URL; ?>/admin-delete-user.php?id=<?php echo $user['user_id']; ?>" 
                                   class="btn-small btn-delete"
                                   onclick="return confirm('Delete this user? This action cannot be undone!');">
                                    <i class="fas fa-trash"></i> Delete
                                </a>
                            <?php else: ?>
                                <span class="badge badge-info">You</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</main>

<?php include __DIR__ . '/../../includes/footer.php'; ?>