<?php
// views/dashboard/index.php
$pageTitle = "Dashboard";
?>

<?php include __DIR__ . '/../../includes/header.php'; ?>
<?php include __DIR__ . '/../../includes/navbar.php'; ?>

<main class="container">
    <div class="dashboard-container">
        <!-- Sidebar -->
        <aside class="dashboard-sidebar">
            <h3>Dashboard Menu</h3>
            <ul class="sidebar-menu">
                <li><a href="<?php echo BASE_URL; ?>/dashboard.php?view=overview" class="<?php echo (!isset($_GET['view']) || $_GET['view'] === 'overview') ? 'active' : ''; ?>"><i class="fas fa-home"></i> Overview</a></li>
                <li><a href="<?php echo BASE_URL; ?>/dashboard.php?view=profile" class="<?php echo (isset($_GET['view']) && $_GET['view'] === 'profile') ? 'active' : ''; ?>"><i class="fas fa-user"></i> Profile</a></li>
                <li><a href="<?php echo BASE_URL; ?>/dashboard.php?view=my-events" class="<?php echo (isset($_GET['view']) && $_GET['view'] === 'my-events') ? 'active' : ''; ?>"><i class="fas fa-calendar-alt"></i> My Events</a></li>
                <li><a href="<?php echo BASE_URL; ?>/dashboard.php?view=my-registrations" class="<?php echo (isset($_GET['view']) && $_GET['view'] === 'my-registrations') ? 'active' : ''; ?>"><i class="fas fa-ticket-alt"></i> My Registrations</a></li>
            </ul>
        </aside>
        
        <!-- Main Content -->
        <div class="dashboard-main">
            <?php if (isset($_SESSION['success'])): ?>
                <div class="alert alert-success">
                    <?php echo h($_SESSION['success']); unset($_SESSION['success']); ?>
                </div>
            <?php endif; ?>
            
            <?php if (isset($_SESSION['error'])): ?>
                <div class="alert alert-error">
                    <?php echo h($_SESSION['error']); unset($_SESSION['error']); ?>
                </div>
            <?php endif; ?>
            
            <h2>Welcome, <?php echo h($user['fullname']); ?>!</h2>
            <p class="user-info">
                <strong>Email:</strong> <?php echo h($user['email']); ?><br>
                <strong>Category:</strong> <?php echo ucfirst(h($user['category'])); ?>
            </p>
            
            <div class="dashboard-stats">
                <div class="stat-card">
                    <i class="fas fa-calendar-alt"></i>
                    <h3><?php echo count($myEvents); ?></h3>
                    <p>My Events</p>
                </div>
                
                <div class="stat-card">
                    <i class="fas fa-ticket-alt"></i>
                    <h3><?php echo count($myRegistrations); ?></h3>
                    <p>Event Registrations</p>
                </div>
            </div>
            
            <div class="quick-actions">
                <h3>Quick Actions</h3>
                <a href="<?php echo BASE_URL; ?>/create-event.php" class="btn btn-primary"><i class="fas fa-plus"></i> Create New Event</a>
                <a href="<?php echo BASE_URL; ?>/index.php" class="btn btn-outline"><i class="fas fa-search"></i> Browse Events</a>
            </div>
            
            <!-- Recent Events -->
            <div class="recent-section">
                <h3>My Recent Events</h3>
                <?php if (empty($myEvents)): ?>
                    <p>You haven't created any events yet.</p>
                <?php else: ?>
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Event Name</th>
                                <th>Date</th>
                                <th>Category</th>
                                <th>Participants</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach (array_slice($myEvents, 0, 5) as $event): ?>
                                <tr>
                                    <td><?php echo h($event['event_name']); ?></td>
                                    <td><?php echo date('d M Y', strtotime($event['event_date'])); ?></td>
                                    <td><?php echo h($event['category']); ?></td>
                                    <td><?php echo $registrationModel->getParticipantCount($event['event_id']); ?></td>
                                    <td>
                                        <a href="<?php echo BASE_URL; ?>/event.php?id=<?php echo $event['event_id']; ?>" class="btn-small">View</a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
            
            <!-- Recent Registrations -->
            <div class="recent-section">
                <h3>My Recent Registrations</h3>
                <?php if (empty($myRegistrations)): ?>
                    <p>You haven't registered for any events yet.</p>
                <?php else: ?>
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Event Name</th>
                                <th>Date</th>
                                <th>Venue</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach (array_slice($myRegistrations, 0, 5) as $reg): ?>
                                <tr>
                                    <td><?php echo h($reg['event_name']); ?></td>
                                    <td><?php echo date('d M Y', strtotime($reg['event_date'])); ?></td>
                                    <td><?php echo h($reg['venue']); ?></td>
                                    <td>
                                        <a href="<?php echo BASE_URL; ?>/event.php?id=<?php echo $reg['event_id']; ?>" class="btn-small">View</a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>
    </div>
</main>

<?php include __DIR__ . '/../../includes/footer.php'; ?>