<?php
// views/dashboard/my-events.php
$pageTitle = "My Events";
?>

<?php include __DIR__ . '/../../includes/header.php'; ?>
<?php include __DIR__ . '/../../includes/navbar.php'; ?>

<main class="container">
    <div class="dashboard-container">
        <!-- Sidebar -->
        <aside class="dashboard-sidebar">
            <h3>Dashboard Menu</h3>
            <ul class="sidebar-menu">
                <li><a href="<?php echo BASE_URL; ?>/dashboard.php?view=overview"><i class="fas fa-home"></i> Overview</a></li>
                <li><a href="<?php echo BASE_URL; ?>/dashboard.php?view=profile"><i class="fas fa-user"></i> Profile</a></li>
                <li><a href="<?php echo BASE_URL; ?>/dashboard.php?view=my-events" class="active"><i class="fas fa-calendar-alt"></i> My Events</a></li>
                <li><a href="<?php echo BASE_URL; ?>/dashboard.php?view=my-registrations"><i class="fas fa-ticket-alt"></i> My Registrations</a></li>
            </ul>
        </aside>
        
        <!-- Main Content -->
        <div class="dashboard-main">
            <div class="page-header">
                <h2>My Events</h2>
                <a href="<?php echo BASE_URL; ?>/create-event.php" class="btn btn-primary"><i class="fas fa-plus"></i> Create New Event</a>
            </div>
            
            <?php if (empty($myEvents)): ?>
                <div class="empty-state">
                    <i class="fas fa-calendar-times"></i>
                    <p>You haven't created any events yet.</p>
                    <a href="<?php echo BASE_URL; ?>/create-event.php" class="btn btn-primary">Create Your First Event</a>
                </div>
            <?php else: ?>
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Event Name</th>
                            <th>Category</th>
                            <th>Date</th>
                            <th>Venue</th>
                            <th>Mode</th>
                            <th>Participants</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($myEvents as $event): ?>
                            <tr>
                                <td><?php echo h($event['event_name']); ?></td>
                                <td><?php echo h($event['category']); ?></td>
                                <td><?php echo date('d M Y', strtotime($event['event_date'])); ?></td>
                                <td><?php echo h($event['venue']); ?></td>
                                <td><?php echo h($event['mode']); ?></td>
                                <td><?php echo $event['participant_count']; ?><?php echo $event['max_participants'] ? '/' . $event['max_participants'] : ''; ?></td>
                                <td><span class="badge badge-<?php echo $event['status']; ?>"><?php echo ucfirst($event['status']); ?></span></td>
                                <td class="action-buttons">
                                    <a href="<?php echo BASE_URL; ?>/event.php?id=<?php echo $event['event_id']; ?>" class="btn-small btn-view"><i class="fas fa-eye"></i> View</a>
                                    <a href="<?php echo BASE_URL; ?>/edit-event.php?id=<?php echo $event['event_id']; ?>" class="btn-small btn-edit"><i class="fas fa-edit"></i> Edit</a>
                                    <a href="<?php echo BASE_URL; ?>/delete-event.php?id=<?php echo $event['event_id']; ?>" class="btn-small btn-delete" onclick="return confirm('Are you sure you want to delete this event?');"><i class="fas fa-trash"></i> Delete</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
    </div>
</main>

<?php include __DIR__ . '/../../includes/footer.php'; ?>