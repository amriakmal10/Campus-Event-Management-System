<?php
// views/dashboard/my-registrations.php
$pageTitle = "My Registrations";
?>

<?php include __DIR__ . '/../../includes/header.php'; ?>
<?php include __DIR__ . '/../../includes/navbar.php'; ?>

<main class="container">
    <div class="dashboard-container">
        <!-- Sidebar -->
        <aside class="dashboard-sidebar">
            <h3>Dashboard Menu</h3>
            <ul class="sidebar-menu">
                <li><a href="<?php echo BASE_URL; ?>/dashboard.php?view=overview"><i class="fas fa-home"></i> Overview</a></li>
                <li><a href="<?php echo BASE_URL; ?>/dashboard.php?view=profile"><i class="fas fa-user"></i> Profile</a></li>
                <li><a href="<?php echo BASE_URL; ?>/dashboard.php?view=my-events"><i class="fas fa-calendar-alt"></i> My Events</a></li>
                <li><a href="<?php echo BASE_URL; ?>/dashboard.php?view=my-registrations" class="active"><i class="fas fa-ticket-alt"></i> My Registrations</a></li>
            </ul>
        </aside>
        
        <!-- Main Content -->
        <div class="dashboard-main">
            <div class="page-header">
                <h2>My Event Registrations</h2>
                <a href="<?php echo BASE_URL; ?>/index.php" class="btn btn-outline"><i class="fas fa-search"></i> Browse Events</a>
            </div>
            
            <?php if (empty($myRegistrations)): ?>
                <div class="empty-state">
                    <i class="fas fa-ticket-alt"></i>
                    <p>You haven't registered for any events yet.</p>
                    <a href="<?php echo BASE_URL; ?>/index.php" class="btn btn-primary">Browse Available Events</a>
                </div>
            <?php else: ?>
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Event Name</th>
                            <th>Date</th>
                            <th>Time</th>
                            <th>Venue</th>
                            <th>Mode</th>
                            <th>Registration Date</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($myRegistrations as $reg): ?>
                            <tr>
                                <td><?php echo h($reg['event_name']); ?></td>
                                <td><?php echo date('d M Y', strtotime($reg['event_date'])); ?></td>
                                <td><?php echo date('h:i A', strtotime($reg['event_time'])); ?></td>
                                <td><?php echo h($reg['venue']); ?></td>
                                <td><?php echo h($reg['mode']); ?></td>
                                <td><?php echo date('d M Y', strtotime($reg['registration_date'])); ?></td>
                                <td class="action-buttons">
                                    <a href="<?php echo BASE_URL; ?>/event.php?id=<?php echo $reg['event_id']; ?>" class="btn-small btn-view"><i class="fas fa-eye"></i> View</a>
                                    <a href="<?php echo BASE_URL; ?>/cancel-registration.php?event_id=<?php echo $reg['event_id']; ?>" class="btn-small btn-delete" onclick="return confirm('Are you sure you want to cancel this registration?');"><i class="fas fa-times"></i> Cancel</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
    </div>
</main>

<?php include __DIR__ . '/../../includes/footer.php'; ?>