<?php
// views/dashboard/profile.php
$pageTitle = "My Profile";
?>

<?php include __DIR__ . '/../../includes/header.php'; ?>
<?php include __DIR__ . '/../../includes/navbar.php'; ?>

<main class="container">
    <div class="dashboard-container">
        <!-- Sidebar -->
        <aside class="dashboard-sidebar">
            <h3>Dashboard Menu</h3>
            <ul class="sidebar-menu">
                <li><a href="<?php echo BASE_URL; ?>/dashboard.php?view=overview"><i class="fas fa-home"></i> Overview</a></li>
                <li><a href="<?php echo BASE_URL; ?>/dashboard.php?view=profile" class="active"><i class="fas fa-user"></i> Profile</a></li>
                <li><a href="<?php echo BASE_URL; ?>/dashboard.php?view=my-events"><i class="fas fa-calendar-alt"></i> My Events</a></li>
                <li><a href="<?php echo BASE_URL; ?>/dashboard.php?view=my-registrations"><i class="fas fa-ticket-alt"></i> My Registrations</a></li>
            </ul>
        </aside>
        
        <!-- Main Content -->
        <div class="dashboard-main">
            <h2>My Profile</h2>
            
            <?php if (!empty($errors)): ?>
                <div class="alert alert-error">
                    <ul>
                        <?php foreach ($errors as $error): ?>
                            <li><?php echo h($error); ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>
            
            <div class="profile-card">
                <form method="POST" action="<?php echo BASE_URL; ?>/dashboard.php?view=profile">
                    <div class="form-group">
                        <label for="fullname">Full Name *</label>
                        <input type="text" id="fullname" name="fullname" value="<?php echo h($user['fullname']); ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="email">Email (Cannot be changed)</label>
                        <input type="email" id="email" value="<?php echo h($user['email']); ?>" disabled>
                    </div>
                    
                    <div class="form-group">
                        <label for="phone">Phone *</label>
                        <input type="tel" id="phone" name="phone" value="<?php echo h($user['phone']); ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="organization">Organization *</label>
                        <input type="text" id="organization" name="organization" value="<?php echo h($user['organization']); ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <label>Category</label>
                        <input type="text" value="<?php echo ucfirst(h($user['category'])); ?>" disabled>
                    </div>
                    
                    <div class="form-group">
                        <label>Recommended Events</label>
                        <input type="text" value="<?php echo h($user['recommend_events']); ?>" disabled>
                    </div>
                    
                    <div class="form-actions">
                        <button type="submit" class="btn btn-primary">Update Profile</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</main>

<?php include __DIR__ . '/../../includes/footer.php'; ?>