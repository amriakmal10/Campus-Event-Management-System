<?php
// views/auth/register.php
$pageTitle = "Register";
?>

<?php include __DIR__ . '/../../includes/header.php'; ?>
<?php include __DIR__ . '/../../includes/navbar.php'; ?>

<main class="container">
    <div class="auth-container">
        <div class="auth-card">
            <h2>Register for UMSER</h2>
            
            <?php if (!empty($errors)): ?>
                <div class="alert alert-error">
                    <ul>
                        <?php foreach ($errors as $error): ?>
                            <li><?php echo h($error); ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>
            
            <form method="POST" action="<?php echo BASE_URL; ?>/register.php">
                <fieldset class="form-group">
                    <legend>Category *</legend>
                    <label class="radio-label">
                        <input type="radio" name="category" value="staff" <?php echo (isset($_POST['category']) && $_POST['category'] === 'staff') ? 'checked' : ''; ?> required>
                        Staff
                    </label>
                    <label class="radio-label">
                        <input type="radio" name="category" value="student" <?php echo (isset($_POST['category']) && $_POST['category'] === 'student') ? 'checked' : ''; ?>>
                        Student
                    </label>
                    <label class="radio-label">
                        <input type="radio" name="category" value="public" <?php echo (isset($_POST['category']) && $_POST['category'] === 'public') ? 'checked' : ''; ?>>
                        Public
                    </label>
                </fieldset>
                
                <div class="form-group">
                    <label for="fullname">Full Name *</label>
                    <input type="text" id="fullname" name="fullname" value="<?php echo h($_POST['fullname'] ?? ''); ?>" required>
                </div>
                
                <div class="form-group">
                    <label for="email">Email *</label>
                    <input type="email" id="email" name="email" value="<?php echo h($_POST['email'] ?? ''); ?>" required>
                </div>
                
                <div class="form-group">
                    <label for="phone">Phone *</label>
                    <input type="tel" id="phone" name="phone" value="<?php echo h($_POST['phone'] ?? ''); ?>" required>
                </div>
                
                <div class="form-group">
                    <label for="organization">Organization *</label>
                    <input type="text" id="organization" name="organization" value="<?php echo h($_POST['organization'] ?? ''); ?>" required>
                </div>
                
                <div class="form-group">
                    <label for="password">Password * (minimum 6 characters)</label>
                    <input type="password" id="password" name="password" minlength="6" required>
                </div>
                
                <div class="form-group">
                    <label for="confirm_password">Confirm Password *</label>
                    <input type="password" id="confirm_password" name="confirm_password" minlength="6" required>
                </div>
                
                <fieldset class="form-group">
                    <legend>Recommend Events * (Select at least one)</legend>
                    <label class="checkbox-label">
                        <input type="checkbox" name="recommend_events[]" value="Workshop" <?php echo (isset($_POST['recommend_events']) && in_array('Workshop', $_POST['recommend_events'])) ? 'checked' : ''; ?>>
                        Workshop
                    </label>
                    <label class="checkbox-label">
                        <input type="checkbox" name="recommend_events[]" value="Seminar" <?php echo (isset($_POST['recommend_events']) && in_array('Seminar', $_POST['recommend_events'])) ? 'checked' : ''; ?>>
                        Seminar
                    </label>
                    <label class="checkbox-label">
                        <input type="checkbox" name="recommend_events[]" value="Competition" <?php echo (isset($_POST['recommend_events']) && in_array('Competition', $_POST['recommend_events'])) ? 'checked' : ''; ?>>
                        Competition
                    </label>
                    <label class="checkbox-label">
                        <input type="checkbox" name="recommend_events[]" value="Festival" <?php echo (isset($_POST['recommend_events']) && in_array('Festival', $_POST['recommend_events'])) ? 'checked' : ''; ?>>
                        Festival
                    </label>
                    <label class="checkbox-label">
                        <input type="checkbox" name="recommend_events[]" value="Sport" <?php echo (isset($_POST['recommend_events']) && in_array('Sport', $_POST['recommend_events'])) ? 'checked' : ''; ?>>
                        Sport
                    </label>
                    <label class="checkbox-label">
                        <input type="checkbox" name="recommend_events[]" value="Course" <?php echo (isset($_POST['recommend_events']) && in_array('Course', $_POST['recommend_events'])) ? 'checked' : ''; ?>>
                        Course
                    </label>
                </fieldset>
                
                <div class="form-actions">
                    <button type="submit" class="btn btn-primary">Register</button>
                    <button type="reset" class="btn btn-outline">Reset</button>
                </div>
                
                <p class="auth-link">
                    Already have an account? <a href="<?php echo BASE_URL; ?>/login.php">Login here</a>
                </p>
            </form>
        </div>
    </div>
</main>

<?php include __DIR__ . '/../../includes/footer.php'; ?>