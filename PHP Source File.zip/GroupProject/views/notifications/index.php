<?php
// views/notifications/index.php
$pageTitle = "Notifications";
?>

<?php include __DIR__ . '/../../includes/header.php'; ?>
<?php include __DIR__ . '/../../includes/navbar.php'; ?>

<main class="container">
    <div class="page-header">
        <h2><i class="fas fa-bell"></i> Notifications</h2>
        <?php if ($unreadCount > 0): ?>
            <a href="<?php echo BASE_URL; ?>/mark-all-read.php" class="btn btn-outline"><i class="fas fa-check-double"></i> Mark All as Read</a>
        <?php endif; ?>
    </div>
    
    <?php if (isset($_SESSION['success'])): ?>
        <div class="alert alert-success">
            <?php echo h($_SESSION['success']); unset($_SESSION['success']); ?>
        </div>
    <?php endif; ?>
    
    <?php if (empty($notifications)): ?>
        <div class="empty-state">
            <i class="fas fa-bell-slash"></i>
            <p>No notifications yet.</p>
            <a href="<?php echo BASE_URL; ?>/index.php" class="btn btn-primary">Browse Events</a>
        </div>
    <?php else: ?>
        <div class="notifications-list">
            <?php foreach ($notifications as $notification): ?>
                <div class="notification-card <?php echo $notification['is_read'] ? 'read' : 'unread'; ?>">
                    <div class="notification-icon">
                        <?php if ($notification['type'] === 'registration'): ?>
                            <i class="fas fa-check-circle" style="color: #28a745;"></i>
                        <?php elseif ($notification['type'] === 'reminder'): ?>
                            <i class="fas fa-clock" style="color: #f39c12;"></i>
                        <?php elseif ($notification['type'] === 'update'): ?>
                            <i class="fas fa-info-circle" style="color: #3498db;"></i>
                        <?php elseif ($notification['type'] === 'cancellation'): ?>
                            <i class="fas fa-times-circle" style="color: #e74c3c;"></i>
                        <?php elseif ($notification['type'] === 'message'): ?>
                            <i class="fas fa-envelope" style="color: #9b59b6;"></i>
                        <?php else: ?>
                            <i class="fas fa-bell" style="color: #95a5a6;"></i>
                        <?php endif; ?>
                    </div>
                    
                    <div class="notification-content">
                        <h4><?php echo h($notification['title']); ?></h4>
                        <p><?php echo h($notification['message']); ?></p>
                        <?php if ($notification['event_name']): ?>
                            <p class="notification-event"><i class="fas fa-calendar"></i> <?php echo h($notification['event_name']); ?></p>
                        <?php endif; ?>
                        <p class="notification-time"><i class="fas fa-clock"></i> <?php echo date('d M Y, h:i A', strtotime($notification['created_at'])); ?></p>
                    </div>
                    
                    <div class="notification-actions">
                        <?php if ($notification['event_id']): ?>
                            <a href="<?php echo BASE_URL; ?>/event.php?id=<?php echo $notification['event_id']; ?>" class="btn-small btn-view">View Event</a>
                        <?php endif; ?>
                        <?php if (!$notification['is_read']): ?>
                            <a href="<?php echo BASE_URL; ?>/mark-read.php?id=<?php echo $notification['notification_id']; ?>" class="btn-small btn-primary">Mark as Read</a>
                        <?php endif; ?>
                        <a href="<?php echo BASE_URL; ?>/delete-notification.php?id=<?php echo $notification['notification_id']; ?>" class="btn-small btn-delete" onclick="return confirm('Delete this notification?');">Delete</a>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
    
    <div class="back-link">
        <a href="<?php echo BASE_URL; ?>/dashboard.php" class="btn btn-outline"><i class="fas fa-arrow-left"></i> Back to Dashboard</a>
    </div>
</main>

<?php include __DIR__ . '/../../includes/footer.php'; ?>