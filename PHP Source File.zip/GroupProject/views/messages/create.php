<?php
// views/messages/create.php
$pageTitle = "Send Message to Participants";
?>

<?php include __DIR__ . '/../../includes/header.php'; ?>
<?php include __DIR__ . '/../../includes/navbar.php'; ?>

<main class="container">
    <div class="form-container">
        <h2>Send Message to Participants</h2>
        
        <div class="event-info-box">
            <p><strong>Event:</strong> <?php echo h($event['event_name']); ?></p>
            <p><strong>Participants:</strong> <?php echo $participantCount; ?></p>
            <p class="info-note"><i class="fas fa-info-circle"></i> This message will be sent to all registered participants and they will receive a notification.</p>
        </div>
        
        <?php if (!empty($errors)): ?>
            <div class="alert alert-error">
                <ul>
                    <?php foreach ($errors as $error): ?>
                        <li><?php echo h($error); ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>
        
        <?php if ($participantCount == 0): ?>
            <div class="alert alert-info">
                <p>No participants have registered for this event yet. Messages can only be sent when there are participants.</p>
            </div>
            <a href="<?php echo BASE_URL; ?>/event.php?id=<?php echo $event['event_id']; ?>" class="btn btn-outline">Back to Event</a>
        <?php else: ?>
            <form method="POST" action="<?php echo BASE_URL; ?>/send-message.php?event_id=<?php echo $event['event_id']; ?>">
                <div class="form-group">
                    <label for="subject">Subject *</label>
                    <input type="text" id="subject" name="subject" value="<?php echo h($_POST['subject'] ?? ''); ?>" required placeholder="e.g., Important Update, Venue Change, Reminder">
                </div>
                
                <div class="form-group">
                    <label for="message">Message *</label>
                    <textarea id="message" name="message" rows="10" required placeholder="Type your message to participants..."><?php echo h($_POST['message'] ?? ''); ?></textarea>
                    <small>This message will be visible to all participants</small>
                </div>
                
                <div class="form-actions">
                    <button type="submit" class="btn btn-primary"><i class="fas fa-paper-plane"></i> Send to All Participants</button>
                    <a href="<?php echo BASE_URL; ?>/event.php?id=<?php echo $event['event_id']; ?>" class="btn btn-outline">Cancel</a>
                </div>
            </form>
        <?php endif; ?>
    </div>
</main>

<?php include __DIR__ . '/../../includes/footer.php'; ?>