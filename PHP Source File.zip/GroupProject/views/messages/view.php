<?php
// views/messages/view.php
$pageTitle = "Event Messages";
?>

<?php include __DIR__ . '/../../includes/header.php'; ?>
<?php include __DIR__ . '/../../includes/navbar.php'; ?>

<main class="container">
    <div class="messages-view-container">
        <h2>Messages for <?php echo h($event['event_name']); ?></h2>
        
        <?php if ($isOwner): ?>
            <div class="page-actions">
                <a href="<?php echo BASE_URL; ?>/send-message.php?event_id=<?php echo $event['event_id']; ?>" class="btn btn-primary"><i class="fas fa-paper-plane"></i> Send New Message</a>
            </div>
        <?php endif; ?>
        
        <?php if (empty($messages)): ?>
            <div class="empty-state">
                <i class="fas fa-envelope-open"></i>
                <p>No messages yet for this event.</p>
                <?php if ($isOwner): ?>
                    <a href="<?php echo BASE_URL; ?>/send-message.php?event_id=<?php echo $event['event_id']; ?>" class="btn btn-primary">Send First Message</a>
                <?php endif; ?>
            </div>
        <?php else: ?>
            <div class="messages-list">
                <?php foreach ($messages as $message): ?>
                    <div class="message-card">
                        <div class="message-header">
                            <div class="message-from">
                                <i class="fas fa-user-circle"></i>
                                <strong><?php echo h($message['sender_name']); ?></strong>
                                <span class="message-role">(Organizer)</span>
                            </div>
                            <div class="message-date">
                                <i class="fas fa-clock"></i>
                                <?php echo date('d M Y, h:i A', strtotime($message['sent_at'])); ?>
                            </div>
                        </div>
                        
                        <div class="message-subject">
                            <h4><?php echo h($message['subject']); ?></h4>
                        </div>
                        
                        <div class="message-body">
                            <p><?php echo nl2br(h($message['message'])); ?></p>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
        
        <div class="back-link">
            <a href="<?php echo BASE_URL; ?>/event.php?id=<?php echo $event['event_id']; ?>" class="btn btn-outline"><i class="fas fa-arrow-left"></i> Back to Event</a>
        </div>
    </div>
</main>

<?php include __DIR__ . '/../../includes/footer.php'; ?>