<?php
// views/feedback/view.php
$pageTitle = "Event Feedback";
?>

<?php include __DIR__ . '/../../includes/header.php'; ?>
<?php include __DIR__ . '/../../includes/navbar.php'; ?>

<main class="container">
    <div class="feedback-view-container">
        <h2>Feedback for <?php echo h($event['event_name']); ?></h2>
        
        <div class="feedback-summary">
            <div class="rating-overview">
                <div class="average-rating">
                    <h3><?php echo $ratingStats['average']; ?></h3>
                    <div class="stars">
                        <?php for ($i = 1; $i <= 5; $i++): ?>
                            <i class="fas fa-star <?php echo $i <= round($ratingStats['average']) ? 'filled' : ''; ?>"></i>
                        <?php endfor; ?>
                    </div>
                    <p><?php echo $ratingStats['total']; ?> reviews</p>
                </div>
                
                <div class="rating-distribution">
                    <?php for ($i = 5; $i >= 1; $i--): ?>
                        <div class="rating-bar">
                            <span class="rating-label"><?php echo $i; ?> <i class="fas fa-star"></i></span>
                            <div class="bar">
                                <?php 
                                $percentage = $ratingStats['total'] > 0 ? ($distribution[$i] / $ratingStats['total']) * 100 : 0;
                                ?>
                                <div class="bar-fill" style="width: <?php echo $percentage; ?>%;"></div>
                            </div>
                            <span class="rating-count"><?php echo $distribution[$i]; ?></span>
                        </div>
                    <?php endfor; ?>
                </div>
            </div>
        </div>
        
        <?php if (empty($feedback)): ?>
            <div class="empty-state">
                <i class="fas fa-comments"></i>
                <p>No feedback yet for this event.</p>
            </div>
        <?php else: ?>
            <div class="feedback-list">
                <h3>Reviews (<?php echo count($feedback); ?>)</h3>
                
                <?php foreach ($feedback as $item): ?>
                    <div class="feedback-item">
                        <div class="feedback-header">
                            <div class="user-info">
                                <strong><?php echo h($item['fullname']); ?></strong>
                                <span class="user-category">(<?php echo ucfirst(h($item['category'])); ?>)</span>
                            </div>
                            <div class="feedback-rating">
                                <?php for ($i = 1; $i <= 5; $i++): ?>
                                    <i class="fas fa-star <?php echo $i <= $item['rating'] ? 'filled' : ''; ?>"></i>
                                <?php endfor; ?>
                            </div>
                        </div>
                        
                        <div class="feedback-content">
                            <p><?php echo nl2br(h($item['comment'])); ?></p>
                        </div>
                        
                        <div class="feedback-footer">
                            <small><i class="fas fa-clock"></i> <?php echo date('d M Y', strtotime($item['created_at'])); ?></small>
                            
                            <?php if (isLoggedIn() && $item['user_id'] == $_SESSION['user_id']): ?>
                                <div class="feedback-actions">
                                    <a href="<?php echo BASE_URL; ?>/edit-feedback.php?id=<?php echo $item['feedback_id']; ?>" class="btn-small btn-edit">Edit</a>
                                    <a href="<?php echo BASE_URL; ?>/delete-feedback.php?id=<?php echo $item['feedback_id']; ?>" class="btn-small btn-delete" onclick="return confirm('Delete your feedback?');">Delete</a>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
        
        <div class="back-link">
            <a href="<?php echo BASE_URL; ?>/event.php?id=<?php echo $event['event_id']; ?>" class="btn btn-outline"><i class="fas fa-arrow-left"></i> Back to Event</a>
        </div>
    </div>
</main>

<?php include __DIR__ . '/../../includes/footer.php'; ?>