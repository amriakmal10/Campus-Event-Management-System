<?php
// views/feedback/edit.php
$pageTitle = "Edit Feedback";
?>

<?php include __DIR__ . '/../../includes/header.php'; ?>
<?php include __DIR__ . '/../../includes/navbar.php'; ?>

<main class="container">
    <div class="form-container">
        <h2>Edit Feedback for <?php echo h($event['event_name']); ?></h2>
        
        <?php if (!empty($errors)): ?>
            <div class="alert alert-error">
                <ul>
                    <?php foreach ($errors as $error): ?>
                        <li><?php echo h($error); ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>
        
        <div class="event-info-box">
            <p><strong>Event:</strong> <?php echo h($event['event_name']); ?></p>
            <p><strong>Date:</strong> <?php echo date('d M Y', strtotime($event['event_date'])); ?></p>
            <p><strong>Your Current Rating:</strong> <?php echo $existingFeedback['rating']; ?>/5 stars</p>
        </div>
        
        <form method="POST" action="<?php echo BASE_URL; ?>/edit-feedback.php?id=<?php echo $existingFeedback['feedback_id']; ?>">
            <div class="form-group">
                <label>Rating *</label>
                <div class="star-rating">
                    <?php for ($i = 5; $i >= 1; $i--): ?>
                        <input type="radio" name="rating" value="<?php echo $i; ?>" id="star<?php echo $i; ?>" <?php echo ($existingFeedback['rating'] == $i) ? 'checked' : ''; ?> required>
                        <label for="star<?php echo $i; ?>" title="<?php echo $i; ?> stars"><i class="fas fa-star"></i></label>
                    <?php endfor; ?>
                </div>
                <small>Click on the stars to rate (5 = Excellent, 1 = Poor)</small>
            </div>
            
            <div class="form-group">
                <label for="comment">Your Feedback *</label>
                <textarea id="comment" name="comment" rows="8" required placeholder="Share your experience with this event..."><?php echo h($existingFeedback['comment']); ?></textarea>
                <small>Tell us what you liked or what could be improved</small>
            </div>
            
            <div class="form-actions">
                <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Update Feedback</button>
                <a href="<?php echo BASE_URL; ?>/event.php?id=<?php echo $event['event_id']; ?>" class="btn btn-outline">Cancel</a>
                <a href="<?php echo BASE_URL; ?>/delete-feedback.php?id=<?php echo $existingFeedback['feedback_id']; ?>" class="btn btn-danger" onclick="return confirm('Delete your feedback?');"><i class="fas fa-trash"></i> Delete</a>
            </div>
        </form>
    </div>
</main>

<?php include __DIR__ . '/../../includes/footer.php'; ?>