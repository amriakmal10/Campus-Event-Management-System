<?php
// views/feedback/create.php
$pageTitle = "Give Feedback";
?>

<?php include __DIR__ . '/../../includes/header.php'; ?>
<?php include __DIR__ . '/../../includes/navbar.php'; ?>

<main class="container">
    <div class="form-container">
        <h2>Give Feedback for <?php echo h($event['event_name']); ?></h2>
        
        <?php if (!empty($errors)): ?>
            <div class="alert alert-error">
                <ul>
                    <?php foreach ($errors as $error): ?>
                        <li><?php echo h($error); ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>
        
        <div class="event-info-box">
            <p><strong>Event:</strong> <?php echo h($event['event_name']); ?></p>
            <p><strong>Date:</strong> <?php echo date('d M Y', strtotime($event['event_date'])); ?></p>
            <p><strong>Venue:</strong> <?php echo h($event['venue']); ?></p>
        </div>
        
        <form method="POST" action="<?php echo BASE_URL; ?>/give-feedback.php?event_id=<?php echo $event['event_id']; ?>">
            <div class="form-group">
                <label>Rating *</label>
                <div class="star-rating">
                    <input type="radio" name="rating" value="5" id="star5" required>
                    <label for="star5" title="5 stars"><i class="fas fa-star"></i></label>
                    
                    <input type="radio" name="rating" value="4" id="star4">
                    <label for="star4" title="4 stars"><i class="fas fa-star"></i></label>
                    
                    <input type="radio" name="rating" value="3" id="star3">
                    <label for="star3" title="3 stars"><i class="fas fa-star"></i></label>
                    
                    <input type="radio" name="rating" value="2" id="star2">
                    <label for="star2" title="2 stars"><i class="fas fa-star"></i></label>
                    
                    <input type="radio" name="rating" value="1" id="star1">
                    <label for="star1" title="1 star"><i class="fas fa-star"></i></label>
                </div>
                <small>Click on the stars to rate (5 = Excellent, 1 = Poor)</small>
            </div>
            
            <div class="form-group">
                <label for="comment">Your Feedback *</label>
                <textarea id="comment" name="comment" rows="8" required placeholder="Share your experience with this event..."><?php echo h($_POST['comment'] ?? ''); ?></textarea>
                <small>Tell us what you liked or what could be improved</small>
            </div>
            
            <div class="form-actions">
                <button type="submit" class="btn btn-primary"><i class="fas fa-paper-plane"></i> Submit Feedback</button>
                <a href="<?php echo BASE_URL; ?>/event.php?id=<?php echo $event['event_id']; ?>" class="btn btn-outline">Cancel</a>
            </div>
        </form>
    </div>
</main>

<?php include __DIR__ . '/../../includes/footer.php'; ?>