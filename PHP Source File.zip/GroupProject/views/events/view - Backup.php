<?php
// views/events/view.php
$pageTitle = h($event['event_name']);
?>

<?php include __DIR__ . '/../../includes/header.php'; ?>
<?php include __DIR__ . '/../../includes/navbar.php'; ?>

<main class="container">
    <div class="event-detail">
        <div class="event-detail-header">
            <h2><?php echo h($event['event_name']); ?></h2>
            <span class="event-category-badge"><?php echo h($event['category']); ?></span>
        </div>
        
        <div class="event-detail-content">
            <div class="event-detail-image">
                <?php if (!empty($event['poster_path'])): ?>
                    <img src="<?php echo BASE_PATH_UPLOADS; ?>events/<?php echo h($event['poster_path']); ?>" alt="<?php echo h($event['event_name']); ?>">
                <?php else: ?>
                    <div class="no-poster-large">No Poster Available</div>
                <?php endif; ?>
            </div>
            
            <div class="event-detail-info">
                <h3>Event Information</h3>
                
                <div class="info-item">
                    <i class="fas fa-calendar"></i>
                    <div>
                        <strong>Date:</strong>
                        <p><?php echo date('l, d F Y', strtotime($event['event_date'])); ?></p>
                    </div>
                </div>
                
                <div class="info-item">
                    <i class="fas fa-clock"></i>
                    <div>
                        <strong>Time:</strong>
                        <p><?php echo date('h:i A', strtotime($event['event_time'])); ?></p>
                    </div>
                </div>
                
                <div class="info-item">
                    <i class="fas fa-map-marker-alt"></i>
                    <div>
                        <strong>Venue:</strong>
                        <p><?php echo h($event['venue']); ?></p>
                    </div>
                </div>
                
                <div class="info-item">
                    <i class="fas fa-globe"></i>
                    <div>
                        <strong>Mode:</strong>
                        <p><?php echo h($event['mode']); ?></p>
                    </div>
                </div>
                
                <div class="info-item">
                    <i class="fas fa-building"></i>
                    <div>
                        <strong>Organizer:</strong>
                        <p><?php echo h($event['organizer']); ?></p>
                    </div>
                </div>
                
                <?php if (!empty($event['contact_person'])): ?>
                <div class="info-item">
                    <i class="fas fa-user"></i>
                    <div>
                        <strong>Contact Person:</strong>
                        <p><?php echo h($event['contact_person']); ?></p>
                    </div>
                </div>
                <?php endif; ?>
                
                <?php if (!empty($event['contact_no'])): ?>
                <div class="info-item">
                    <i class="fas fa-phone"></i>
                    <div>
                        <strong>Contact Number:</strong>
                        <p><?php echo h($event['contact_no']); ?></p>
                    </div>
                </div>
                <?php endif; ?>
                
                <div class="info-item">
                    <i class="fas fa-users"></i>
                    <div>
                        <strong>Participants:</strong>
                        <p><?php echo $participantCount; ?><?php echo $event['max_participants'] ? ' / ' . $event['max_participants'] : ''; ?></p>
                    </div>
                </div>
                
                <div class="info-item">
                    <i class="fas fa-dollar-sign"></i>
                    <div>
                        <strong>Fee:</strong>
                        <p><?php echo $event['fee'] > 0 ? 'RM ' . number_format($event['fee'], 2) : 'Free'; ?></p>
                    </div>
                </div>
                
                <div class="info-item">
                    <i class="fas fa-calendar-times"></i>
                    <div>
                        <strong>Registration Closes:</strong>
                        <p><?php echo date('d F Y', strtotime($event['registration_close_date'])); ?></p>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="event-description">
            <h3>Description</h3>
            <p><?php echo nl2br(h($event['description'])); ?></p>
        </div>
        
        <?php if (!empty($event['remarks'])): ?>
        <div class="event-remarks">
            <h3>Additional Notes</h3>
            <p><?php echo nl2br(h($event['remarks'])); ?></p>
        </div>
        <?php endif; ?>
        
        <div class="event-actions">
            <?php if (isLoggedIn()): ?>
                <?php if ($isRegistered): ?>
                    <div class="alert alert-success">
                        <i class="fas fa-check-circle"></i> You are registered for this event!
                    </div>
                    <a href="<?php echo BASE_URL; ?>/cancel-registration.php?event_id=<?php echo $event['event_id']; ?>" class="btn btn-danger" onclick="return confirm('Are you sure you want to cancel your registration?');">Cancel Registration</a>
                <?php elseif ($event['max_participants'] && $participantCount >= $event['max_participants']): ?>
                    <div class="alert alert-error">
                        <i class="fas fa-exclamation-circle"></i> This event is full.
                    </div>
                <?php elseif (date('Y-m-d') > $event['registration_close_date']): ?>
                    <div class="alert alert-error">
                        <i class="fas fa-exclamation-circle"></i> Registration for this event has closed.
                    </div>
                <?php else: ?>
                    <form action="<?php echo BASE_URL; ?>/register-event.php" method="POST">
                        <input type="hidden" name="event_id" value="<?php echo $event['event_id']; ?>">
                        <button type="submit" class="btn btn-primary btn-large"><i class="fas fa-ticket-alt"></i> Register for this Event</button>
                    </form>
                <?php endif; ?>
            <?php else: ?>
                <div class="alert alert-info">
                    <i class="fas fa-info-circle"></i> Please <a href="<?php echo BASE_URL; ?>/login.php">login</a> to register for this event.
                </div>
            <?php endif; ?>
            
            <a href="<?php echo BASE_URL; ?>/index.php" class="btn btn-outline">Back to Events</a>
        </div>
    </div>
</main>

<?php include __DIR__ . '/../../includes/footer.php'; ?>