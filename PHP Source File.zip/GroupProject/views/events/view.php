<?php
// views/events/view.php
// UPDATED VERSION - With Feedback and Messaging Integration
$pageTitle = h($event['event_name']);

// Load feedback model to get ratings
require_once __DIR__ . '/../../models/Feedback.php';

// Get connection from controller or create new one
if (!isset($conn)) {
    $conn = getDBConnection();
}

$feedbackModel = new Feedback($conn);
$ratingStats = $feedbackModel->getAverageRating($event['event_id']);

// Check if user has already given feedback
$userFeedback = null;
if (isLoggedIn()) {
    $userFeedback = $feedbackModel->getUserFeedback($event['event_id'], $_SESSION['user_id']);
}

// Check if event has passed
$eventPassed = date('Y-m-d') > $event['event_date'];

// Check if user owns this event
$isOwner = isLoggedIn() && $_SESSION['user_id'] == $event['user_id'];
?>

<?php include __DIR__ . '/../../includes/header.php'; ?>
<?php include __DIR__ . '/../../includes/navbar.php'; ?>

<main class="container">
    <?php if (isset($_SESSION['success'])): ?>
        <div class="alert alert-success">
            <?php echo h($_SESSION['success']); unset($_SESSION['success']); ?>
        </div>
    <?php endif; ?>
    
    <?php if (isset($_SESSION['error'])): ?>
        <div class="alert alert-error">
            <?php echo h($_SESSION['error']); unset($_SESSION['error']); ?>
        </div>
    <?php endif; ?>
    
    <div class="event-detail">
        <div class="event-detail-header">
            <div>
                <h2><?php echo h($event['event_name']); ?></h2>
                <span class="event-category-badge"><?php echo h($event['category']); ?></span>
                
                <!-- Rating Display -->
                <?php if ($ratingStats['total'] > 0): ?>
                    <div class="event-rating-badge">
                        <i class="fas fa-star" style="color: #f39c12;"></i>
                        <?php echo $ratingStats['average']; ?> (<?php echo $ratingStats['total']; ?> reviews)
                    </div>
                <?php endif; ?>
            </div>
            <span class="badge badge-<?php echo $event['status']; ?>"><?php echo ucfirst($event['status']); ?></span>
        </div>
        
        <div class="event-detail-content">
            <div class="event-detail-image">
                <?php if (!empty($event['poster_path'])): ?>
                    <img src="<?php echo BASE_PATH_UPLOADS; ?>events/<?php echo h($event['poster_path']); ?>" alt="<?php echo h($event['event_name']); ?>">
                <?php else: ?>
                    <div class="no-poster-large">No Poster Available</div>
                <?php endif; ?>
            </div>
            
            <div class="event-detail-info">
                <h3>Event Information</h3>
                
                <div class="info-item">
                    <i class="fas fa-calendar"></i>
                    <div>
                        <strong>Date:</strong>
                        <p><?php echo date('l, d F Y', strtotime($event['event_date'])); ?></p>
                    </div>
                </div>
                
                <div class="info-item">
                    <i class="fas fa-clock"></i>
                    <div>
                        <strong>Time:</strong>
                        <p><?php echo date('h:i A', strtotime($event['event_time'])); ?></p>
                    </div>
                </div>
                
                <div class="info-item">
                    <i class="fas fa-map-marker-alt"></i>
                    <div>
                        <strong>Venue:</strong>
                        <p><?php echo h($event['venue']); ?></p>
                    </div>
                </div>
                
                <div class="info-item">
                    <i class="fas fa-globe"></i>
                    <div>
                        <strong>Mode:</strong>
                        <p><?php echo h($event['mode']); ?></p>
                    </div>
                </div>
                
                <div class="info-item">
                    <i class="fas fa-building"></i>
                    <div>
                        <strong>Organizer:</strong>
                        <p><?php echo h($event['organizer']); ?></p>
                    </div>
                </div>
                
                <?php if (!empty($event['contact_person'])): ?>
                <div class="info-item">
                    <i class="fas fa-user"></i>
                    <div>
                        <strong>Contact Person:</strong>
                        <p><?php echo h($event['contact_person']); ?></p>
                    </div>
                </div>
                <?php endif; ?>
                
                <?php if (!empty($event['contact_no'])): ?>
                <div class="info-item">
                    <i class="fas fa-phone"></i>
                    <div>
                        <strong>Contact Number:</strong>
                        <p><?php echo h($event['contact_no']); ?></p>
                    </div>
                </div>
                <?php endif; ?>
                
                <div class="info-item">
                    <i class="fas fa-users"></i>
                    <div>
                        <strong>Participants:</strong>
                        <p><?php echo $participantCount; ?><?php echo $event['max_participants'] ? ' / ' . $event['max_participants'] : ''; ?></p>
                    </div>
                </div>
                
                <div class="info-item">
                    <i class="fas fa-dollar-sign"></i>
                    <div>
                        <strong>Fee:</strong>
                        <p><?php echo $event['fee'] > 0 ? 'RM ' . number_format($event['fee'], 2) : 'Free'; ?></p>
                    </div>
                </div>
                
                <div class="info-item">
                    <i class="fas fa-calendar-times"></i>
                    <div>
                        <strong>Registration Closes:</strong>
                        <p><?php echo date('d F Y', strtotime($event['registration_close_date'])); ?></p>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="event-description">
            <h3>Description</h3>
            <p><?php echo nl2br(h($event['description'])); ?></p>
        </div>
        
        <?php if (!empty($event['remarks'])): ?>
        <div class="event-remarks">
            <h3>Additional Notes</h3>
            <p><?php echo nl2br(h($event['remarks'])); ?></p>
        </div>
        <?php endif; ?>
        
        <!-- Feedback Section -->
        <div class="event-feedback-section">
            <h3><i class="fas fa-star"></i> Event Feedback & Ratings</h3>
            <?php if ($ratingStats['total'] > 0): ?>
                <p>This event has received <strong><?php echo $ratingStats['total']; ?></strong> reviews with an average rating of <strong><?php echo $ratingStats['average']; ?></strong> stars.</p>
                <a href="<?php echo BASE_URL; ?>/view-feedback.php?event_id=<?php echo $event['event_id']; ?>" class="btn btn-outline"><i class="fas fa-comments"></i> View All Feedback</a>
            <?php else: ?>
                <p>No feedback yet for this event. Be the first to share your experience!</p>
            <?php endif; ?>
        </div>
        
        <!-- Action Buttons -->
        <div class="event-actions">
            <?php if (isLoggedIn()): ?>
                <!-- For Event Owner -->
                <?php if ($isOwner): ?>
                    <a href="<?php echo BASE_URL; ?>/edit-event.php?id=<?php echo $event['event_id']; ?>" class="btn btn-primary"><i class="fas fa-edit"></i> Edit Event</a>
                    <a href="<?php echo BASE_URL; ?>/send-message.php?event_id=<?php echo $event['event_id']; ?>" class="btn btn-outline"><i class="fas fa-paper-plane"></i> Send Message to Participants</a>
                    <a href="<?php echo BASE_URL; ?>/view-messages.php?event_id=<?php echo $event['event_id']; ?>" class="btn btn-outline"><i class="fas fa-envelope"></i> View Messages</a>
                    <a href="<?php echo BASE_URL; ?>/delete-event.php?id=<?php echo $event['event_id']; ?>" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this event?');"><i class="fas fa-trash"></i> Delete Event</a>
                
                <!-- For Registered Participants -->
                <?php elseif ($isRegistered): ?>
                    <div class="alert alert-success">
                        <i class="fas fa-check-circle"></i> You are registered for this event!
                    </div>
                    <a href="<?php echo BASE_URL; ?>/cancel-registration.php?event_id=<?php echo $event['event_id']; ?>" class="btn btn-danger" onclick="return confirm('Are you sure you want to cancel your registration?');"><i class="fas fa-times"></i> Cancel Registration</a>
                    <a href="<?php echo BASE_URL; ?>/view-messages.php?event_id=<?php echo $event['event_id']; ?>" class="btn btn-outline"><i class="fas fa-envelope"></i> View Messages</a>
                    
                    <!-- Feedback Button (only if event has passed) -->
                    <?php if ($eventPassed): ?>
                        <?php if ($userFeedback): ?>
                            <a href="<?php echo BASE_URL; ?>/edit-feedback.php?id=<?php echo $userFeedback['feedback_id']; ?>" class="btn btn-outline"><i class="fas fa-edit"></i> Edit Your Feedback</a>
                            <a href="<?php echo BASE_URL; ?>/view-feedback.php?event_id=<?php echo $event['event_id']; ?>" class="btn btn-outline"><i class="fas fa-star"></i> View All Reviews</a>
                        <?php else: ?>
                            <a href="<?php echo BASE_URL; ?>/give-feedback.php?event_id=<?php echo $event['event_id']; ?>" class="btn btn-primary"><i class="fas fa-star"></i> Give Feedback</a>
                        <?php endif; ?>
                    <?php endif; ?>
                
                <!-- For Others (Not Registered) -->
                <?php else: ?>
                    <?php 
                    $isFull = $event['max_participants'] && $participantCount >= $event['max_participants'];
                    $isClosed = date('Y-m-d') > $event['registration_close_date'];
                    ?>
                    
                    <?php if ($isClosed): ?>
                        <div class="alert alert-error">
                            <i class="fas fa-exclamation-circle"></i> Registration for this event has closed.
                        </div>
                    <?php elseif ($isFull): ?>
                        <div class="alert alert-error">
                            <i class="fas fa-exclamation-circle"></i> This event is full.
                        </div>
                    <?php else: ?>
                        <form action="<?php echo BASE_URL; ?>/register-event.php" method="POST" style="display:inline;">
                            <input type="hidden" name="event_id" value="<?php echo $event['event_id']; ?>">
                            <button type="submit" class="btn btn-primary btn-large"><i class="fas fa-ticket-alt"></i> Register for this Event</button>
                        </form>
                    <?php endif; ?>
                    
                    <!-- View feedback even if not registered -->
                    <?php if ($ratingStats['total'] > 0): ?>
                        <a href="<?php echo BASE_URL; ?>/view-feedback.php?event_id=<?php echo $event['event_id']; ?>" class="btn btn-outline"><i class="fas fa-star"></i> View Reviews</a>
                    <?php endif; ?>
                <?php endif; ?>
            <?php else: ?>
                <div class="alert alert-info">
                    <i class="fas fa-info-circle"></i> Please <a href="<?php echo BASE_URL; ?>/login.php">login</a> to register for this event.
                </div>
                
                <!-- View feedback even if not logged in -->
                <?php if ($ratingStats['total'] > 0): ?>
                    <a href="<?php echo BASE_URL; ?>/view-feedback.php?event_id=<?php echo $event['event_id']; ?>" class="btn btn-outline"><i class="fas fa-star"></i> View Reviews</a>
                <?php endif; ?>
            <?php endif; ?>
            
            <a href="<?php echo BASE_URL; ?>/index.php" class="btn btn-outline"><i class="fas fa-arrow-left"></i> Back to Events</a>
        </div>
    </div>
</main>

<?php include __DIR__ . '/../../includes/footer.php'; ?>