<?php
// views/events/edit.php
$pageTitle = "Edit Event";
?>

<?php include __DIR__ . '/../../includes/header.php'; ?>
<?php include __DIR__ . '/../../includes/navbar.php'; ?>

<main class="container">
    <div class="form-container">
        <h2>Edit Event</h2>
        
        <?php if (!empty($errors)): ?>
            <div class="alert alert-error">
                <ul>
                    <?php foreach ($errors as $error): ?>
                        <li><?php echo h($error); ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>
        
        <form method="POST" action="<?php echo BASE_URL; ?>/edit-event.php?id=<?php echo $event['event_id']; ?>" enctype="multipart/form-data">
            <div class="form-row">
                <div class="form-group">
                    <label for="event_name">Event Name *</label>
                    <input type="text" id="event_name" name="event_name" value="<?php echo h($event['event_name']); ?>" required>
                </div>
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label for="description">Description *</label>
                    <textarea id="description" name="description" rows="4" required><?php echo h($event['description']); ?></textarea>
                </div>
            </div>
            
            <div class="form-row two-cols">
                <div class="form-group">
                    <label for="organizer">Organizer *</label>
                    <input type="text" id="organizer" name="organizer" value="<?php echo h($event['organizer']); ?>" required>
                </div>
                
                <div class="form-group">
                    <label for="category">Category *</label>
                    <select id="category" name="category" required>
                        <option value="">-- Select Category --</option>
                        <option value="Workshop" <?php echo ($event['category'] === 'Workshop') ? 'selected' : ''; ?>>Workshop</option>
                        <option value="Seminar" <?php echo ($event['category'] === 'Seminar') ? 'selected' : ''; ?>>Seminar</option>
                        <option value="Competition" <?php echo ($event['category'] === 'Competition') ? 'selected' : ''; ?>>Competition</option>
                        <option value="Festival" <?php echo ($event['category'] === 'Festival') ? 'selected' : ''; ?>>Festival</option>
                        <option value="Sport" <?php echo ($event['category'] === 'Sport') ? 'selected' : ''; ?>>Sport</option>
                        <option value="Course" <?php echo ($event['category'] === 'Course') ? 'selected' : ''; ?>>Course</option>
                    </select>
                </div>
            </div>
            
            <div class="form-row two-cols">
                <div class="form-group">
                    <label for="contact_person">Contact Person</label>
                    <input type="text" id="contact_person" name="contact_person" value="<?php echo h($event['contact_person']); ?>">
                </div>
                
                <div class="form-group">
                    <label for="contact_no">Contact Number</label>
                    <input type="tel" id="contact_no" name="contact_no" value="<?php echo h($event['contact_no']); ?>">
                </div>
            </div>
            
            <div class="form-row two-cols">
                <div class="form-group">
                    <label for="venue">Venue *</label>
                    <input type="text" id="venue" name="venue" value="<?php echo h($event['venue']); ?>" required>
                </div>
                
                <div class="form-group">
                    <label for="mode">Mode *</label>
                    <select id="mode" name="mode" required>
                        <option value="">-- Select Mode --</option>
                        <option value="Physical" <?php echo ($event['mode'] === 'Physical') ? 'selected' : ''; ?>>Physical</option>
                        <option value="Online" <?php echo ($event['mode'] === 'Online') ? 'selected' : ''; ?>>Online</option>
                        <option value="Hybrid" <?php echo ($event['mode'] === 'Hybrid') ? 'selected' : ''; ?>>Hybrid</option>
                    </select>
                </div>
            </div>
            
            <div class="form-row two-cols">
                <div class="form-group">
                    <label for="event_date">Event Date *</label>
                    <input type="date" id="event_date" name="event_date" value="<?php echo h($event['event_date']); ?>" required>
                </div>
                
                <div class="form-group">
                    <label for="event_time">Event Time *</label>
                    <input type="time" id="event_time" name="event_time" value="<?php echo h($event['event_time']); ?>" required>
                </div>
            </div>
            
            <div class="form-row two-cols">
                <div class="form-group">
                    <label for="registration_close_date">Registration Close Date *</label>
                    <input type="date" id="registration_close_date" name="registration_close_date" value="<?php echo h($event['registration_close_date']); ?>" required>
                </div>
                
                <div class="form-group">
                    <label for="max_participants">Max Participants (Optional)</label>
                    <input type="number" id="max_participants" name="max_participants" value="<?php echo h($event['max_participants']); ?>" min="1">
                </div>
            </div>
            
            <div class="form-row two-cols">
                <div class="form-group">
                    <label for="fee">Fee (RM) *</label>
                    <input type="number" id="fee" name="fee" value="<?php echo h($event['fee']); ?>" min="0" step="0.01" required>
                </div>
                
                <div class="form-group">
                    <label for="poster">Event Poster (Optional - Leave empty to keep current)</label>
                    <input type="file" id="poster" name="poster" accept="image/*">
                    <small>Current: <?php echo h($event['poster_path']); ?></small>
                </div>
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label for="remarks">Remarks / Notes</label>
                    <textarea id="remarks" name="remarks" rows="3"><?php echo h($event['remarks']); ?></textarea>
                </div>
            </div>
            
            <div class="form-actions">
                <button type="submit" class="btn btn-primary">Update Event</button>
                <a href="<?php echo BASE_URL; ?>/dashboard.php?view=my-events" class="btn btn-outline">Cancel</a>
            </div>
        </form>
    </div>
</main>

<?php include __DIR__ . '/../../includes/footer.php'; ?>