<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/controllers/MessageController.php';
$controller = new MessageController();
$controller->create();
?>