<?php
// register-event.php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/controllers/RegistrationController.php';

$controller = new RegistrationController();
$controller->register();
?>