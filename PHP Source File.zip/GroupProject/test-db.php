<?php
// test-db.php - Database Connection Test
require_once __DIR__ . '/config.php';
?>
<!DOCTYPE html>
<html>
<head>
    <title>Database Test - UMSER</title>
    <style>
        body { font-family: Arial; padding: 20px; background: #f4f7f9; }
        .container { max-width: 800px; margin: 0 auto; background: white; padding: 30px; border-radius: 10px; box-shadow: 0 4px 10px rgba(0,0,0,0.1); }
        .success { color: #28a745; }
        .error { color: #dc3545; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { padding: 10px; text-align: left; border-bottom: 1px solid #ddd; }
        th { background: #2c3e50; color: white; }
    </style>
</head>
<body>
    <div class="container">
        <h1>UMSER Database Connection Test</h1>
        
        <?php
        $conn = getDBConnection();
        
        if ($conn) {
            echo "<p class='success'>✅ Database connected successfully!</p>";
            echo "<p><strong>Database:</strong> " . DB_NAME . "</p>";
            
            // Test tables
            echo "<h2>Database Tables</h2>";
            echo "<table>";
            echo "<tr><th>Table Name</th><th>Record Count</th></tr>";
            
            $tables = ['users', 'events', 'event_registrations'];
            
            foreach ($tables as $table) {
                $result = $conn->query("SELECT COUNT(*) as total FROM $table");
                if ($result) {
                    $row = $result->fetch_assoc();
                    echo "<tr><td>$table</td><td>" . $row['total'] . "</td></tr>";
                } else {
                    echo "<tr><td>$table</td><td class='error'>Error</td></tr>";
                }
            }
            
            echo "</table>";
            
            // Display sample users
            echo "<h2>Sample Users</h2>";
            $result = $conn->query("SELECT user_id, fullname, email, category FROM users LIMIT 5");
            if ($result && $result->num_rows > 0) {
                echo "<table>";
                echo "<tr><th>ID</th><th>Name</th><th>Email</th><th>Category</th></tr>";
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . $row['user_id'] . "</td>";
                    echo "<td>" . htmlspecialchars($row['fullname']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['email']) . "</td>";
                    echo "<td>" . ucfirst($row['category']) . "</td>";
                    echo "</tr>";
                }
                echo "</table>";
            }
            
            // Display sample events
            echo "<h2>Sample Events</h2>";
            $result = $conn->query("SELECT event_id, event_name, event_date, category FROM events LIMIT 5");
            if ($result && $result->num_rows > 0) {
                echo "<table>";
                echo "<tr><th>ID</th><th>Event Name</th><th>Date</th><th>Category</th></tr>";
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . $row['event_id'] . "</td>";
                    echo "<td>" . htmlspecialchars($row['event_name']) . "</td>";
                    echo "<td>" . $row['event_date'] . "</td>";
                    echo "<td>" . $row['category'] . "</td>";
                    echo "</tr>";
                }
                echo "</table>";
            }
            
            $conn->close();
            
        } else {
            echo "<p class='error'>❌ Database connection failed!</p>";
            echo "<p>Please check your config.php settings.</p>";
        }
        ?>
        
        <hr style="margin: 30px 0;">
        <p><a href="index.php">← Back to Home</a></p>
    </div>
</body>
</html>