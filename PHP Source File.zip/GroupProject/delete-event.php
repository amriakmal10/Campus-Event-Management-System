<?php
// delete-event.php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/controllers/EventController.php';

requireLogin();

if (isset($_GET['id'])) {
    $controller = new EventController();
    $controller->delete((int)$_GET['id']);
} else {
    redirect('/dashboard.php?view=my-events');
}
?>