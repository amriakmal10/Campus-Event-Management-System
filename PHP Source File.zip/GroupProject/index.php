<?php
// index.php
// Group Project - CEMS
// Group Members: Hanbali (BI23110316), Amri (BI23110304)

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/models/Event.php';
require_once __DIR__ . '/models/Registration.php';

$conn = getDBConnection();
$eventModel = new Event($conn);
$registrationModel = new Registration($conn);

// Get all events
$events = $eventModel->getAll();

// Filter by category if provided
if (isset($_GET['category']) && $_GET['category'] !== '') {
    $category = $_GET['category'];
    $events = array_filter($events, function($event) use ($category) {
        return $event['category'] === $category;
    });
}

$pageTitle = "Home";
?>

<?php include __DIR__ . '/includes/header.php'; ?>
<?php include __DIR__ . '/includes/navbar.php'; ?>

<!-- Hero Banner -->
<header class="hero">
    <div class="overlay"></div>
    <div class="hero-content">
        <img src="<?php echo BASE_PATH_IMG; ?>logoums.png" alt="UMSER Logo" class="logo">
        <h1>UMS Event Registry</h1>
        <p>Organize, manage, and participate in UMS campus events seamlessly</p>
    </div>
</header>

<main class="container">
    <!-- Messages -->
    <?php if (isset($_SESSION['success'])): ?>
        <div class="alert alert-success">
            <?php echo h($_SESSION['success']); unset($_SESSION['success']); ?>
        </div>
    <?php endif; ?>
    
    <?php if (isset($_SESSION['error'])): ?>
        <div class="alert alert-error">
            <?php echo h($_SESSION['error']); unset($_SESSION['error']); ?>
        </div>
    <?php endif; ?>
    
    <!-- About Section -->
    <section class="intro">
        <h2>About UMSER</h2>
        <p>Welcome to the UMS Event Registry. Discover and participate in exciting campus events, workshops, seminars, competitions, and more!</p>
    </section>
    
    <!-- Event Filter -->
    <section class="event-filter">
        <h3>Filter Events</h3>
        <div class="filter-buttons">
            <a href="<?php echo BASE_URL; ?>/index.php" class="filter-btn <?php echo !isset($_GET['category']) ? 'active' : ''; ?>">All</a>
            <a href="<?php echo BASE_URL; ?>/index.php?category=Workshop" class="filter-btn <?php echo (isset($_GET['category']) && $_GET['category'] === 'Workshop') ? 'active' : ''; ?>">Workshop</a>
            <a href="<?php echo BASE_URL; ?>/index.php?category=Seminar" class="filter-btn <?php echo (isset($_GET['category']) && $_GET['category'] === 'Seminar') ? 'active' : ''; ?>">Seminar</a>
            <a href="<?php echo BASE_URL; ?>/index.php?category=Competition" class="filter-btn <?php echo (isset($_GET['category']) && $_GET['category'] === 'Competition') ? 'active' : ''; ?>">Competition</a>
            <a href="<?php echo BASE_URL; ?>/index.php?category=Festival" class="filter-btn <?php echo (isset($_GET['category']) && $_GET['category'] === 'Festival') ? 'active' : ''; ?>">Festival</a>
            <a href="<?php echo BASE_URL; ?>/index.php?category=Sport" class="filter-btn <?php echo (isset($_GET['category']) && $_GET['category'] === 'Sport') ? 'active' : ''; ?>">Sport</a>
            <a href="<?php echo BASE_URL; ?>/index.php?category=Course" class="filter-btn <?php echo (isset($_GET['category']) && $_GET['category'] === 'Course') ? 'active' : ''; ?>">Course</a>
        </div>
    </section>
    
    <!-- Event Listing -->
    <section class="event-listing">
        <h3>Upcoming Events</h3>
        
        <?php if (empty($events)): ?>
            <p class="no-events">No events available at the moment.</p>
        <?php else: ?>
            <div class="event-grid">
                <?php foreach ($events as $event): 
                    $participantCount = $registrationModel->getParticipantCount($event['event_id']);
                    $isFull = $event['max_participants'] && $participantCount >= $event['max_participants'];
                    $isRegistered = isLoggedIn() ? $registrationModel->isRegistered($event['event_id'], $_SESSION['user_id']) : false;
                    $isOwner = isLoggedIn() ? ($event['user_id'] == $_SESSION['user_id']) : false;
                ?>
                    <div class="event-card">
                        <?php if (!empty($event['poster_path'])): ?>
                            <img src="<?php echo BASE_PATH_UPLOADS; ?>events/<?php echo h($event['poster_path']); ?>" alt="<?php echo h($event['event_name']); ?>">
                        <?php else: ?>
                            <div class="no-poster">No Poster</div>
                        <?php endif; ?>
                        
                        <div class="event-card-content">
                            <span class="event-category"><?php echo h($event['category']); ?></span>
                            <h4><?php echo h($event['event_name']); ?></h4>
                            <p class="event-info">
                                <i class="fas fa-calendar"></i> <?php echo date('d M Y', strtotime($event['event_date'])); ?><br>
                                <i class="fas fa-clock"></i> <?php echo date('h:i A', strtotime($event['event_time'])); ?><br>
                                <i class="fas fa-map-marker-alt"></i> <?php echo h($event['venue']); ?><br>
                                <i class="fas fa-users"></i> <?php echo $participantCount; ?><?php echo $event['max_participants'] ? '/' . $event['max_participants'] : ''; ?> participants
                            </p>
                            
                            <div class="event-actions">
                                <a href="<?php echo BASE_URL; ?>/event.php?id=<?php echo $event['event_id']; ?>" class="btn btn-outline">View Details</a>
                                
                                <?php if (isLoggedIn()): ?>
                                    <?php if ($isOwner): ?> 
                                        <span class="badge badge-success">Your Event</span>
                                    <?php elseif ($isRegistered): ?>
                                        <span class="badge badge-success">Registered</span>
                                    <?php elseif ($isFull): ?>
                                        <span class="badge badge-danger">Full</span>
                                    <?php elseif (date('Y-m-d') > $event['registration_close_date']): ?>
                                        <span class="badge badge-danger">Closed</span>
                                    <?php else: ?>
                                        <form action="<?php echo BASE_URL; ?>/register-event.php" method="POST" style="display:inline;">
                                            <input type="hidden" name="event_id" value="<?php echo $event['event_id']; ?>">
                                            <button type="submit" class="btn btn-primary">Register</button>
                                        </form>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <a href="<?php echo BASE_URL; ?>/login.php" class="btn btn-primary">Login to Register</a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </section>
</main>

<?php include __DIR__ . '/includes/footer.php'; ?>
<?php $conn->close(); ?>