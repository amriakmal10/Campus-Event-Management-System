<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/controllers/AdminController.php';

$controller = new AdminController();
$controller->archiveEvent();
?>