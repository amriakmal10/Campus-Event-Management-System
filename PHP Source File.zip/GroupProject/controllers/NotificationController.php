<?php
// controllers/NotificationController.php

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../models/Notification.php';

class NotificationController {
    private $notificationModel;
    private $conn;
    
    public function __construct() {
        requireLogin();
        $this->conn = getDBConnection();
        $this->notificationModel = new Notification($this->conn);
    }
    
    // Show all notifications
    public function index() {
        $user = getCurrentUser();
        $notifications = $this->notificationModel->getUserNotifications($user['user_id']);
        $unreadCount = $this->notificationModel->getUnreadCount($user['user_id']);
        
        require_once __DIR__ . '/../views/notifications/index.php';
    }
    
    // Mark notification as read
    public function markAsRead() {
        if (isset($_GET['id'])) {
            $notificationId = (int)$_GET['id'];
            $userId = $_SESSION['user_id'];
            
            $this->notificationModel->markAsRead($notificationId, $userId);
        }
        
        // Redirect back
        $redirect = $_GET['redirect'] ?? '/notifications.php';
        redirect($redirect);
    }
    
    // Mark all as read
    public function markAllAsRead() {
        $userId = $_SESSION['user_id'];
        
        if ($this->notificationModel->markAllAsRead($userId)) {
            $_SESSION['success'] = "All notifications marked as read.";
        }
        
        redirect('/notifications.php');
    }
    
    // Delete notification
    public function delete() {
        if (isset($_GET['id'])) {
            $notificationId = (int)$_GET['id'];
            $userId = $_SESSION['user_id'];
            
            if ($this->notificationModel->delete($notificationId, $userId)) {
                $_SESSION['success'] = "Notification deleted.";
            } else {
                $_SESSION['error'] = "Failed to delete notification.";
            }
        }
        
        redirect('/notifications.php');
    }
    
    public function __destruct() {
        if ($this->conn) {
            $this->conn->close();
        }
    }
}
?>