<?php
// controllers/DashboardController.php

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../models/User.php';
require_once __DIR__ . '/../models/Event.php';
require_once __DIR__ . '/../models/Registration.php';

class DashboardController {
    private $userModel;
    private $eventModel;
    private $registrationModel;
    private $conn;
    
    public function __construct() {
        requireLogin();
        $this->conn = getDBConnection();
        $this->userModel = new User($this->conn);
        $this->eventModel = new Event($this->conn);
        $this->registrationModel = new Registration($this->conn);
    }
    
    // Show dashboard
    public function index() {
        $view = $_GET['view'] ?? 'overview';
        $user = getCurrentUser();
        
        switch ($view) {
            case 'profile':
                $this->showProfile($user);
                break;
            case 'my-events':
                $this->showMyEvents($user);
                break;
            case 'my-registrations':
                $this->showMyRegistrations($user);
                break;
            case 'overview':
            default:
                $this->showOverview($user);
                break;
        }
    }
    
    // Show overview
    private function showOverview($user) {
        $myEvents = $this->eventModel->getByUserId($user['user_id']);
        $myRegistrations = $this->registrationModel->getUserRegistrations($user['user_id']);
        
        // Pass $registrationModel to the view
        $registrationModel = $this->registrationModel;
        
        require_once __DIR__ . '/../views/dashboard/index.php';
    }
    
    // Show profile
    private function showProfile($user) {
        $errors = [];
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $fullname = trim($_POST['fullname'] ?? '');
            $phone = trim($_POST['phone'] ?? '');
            $organization = trim($_POST['organization'] ?? '');
            
            if (empty($fullname)) $errors[] = "Full name is required.";
            if (empty($phone)) $errors[] = "Phone is required.";
            if (empty($organization)) $errors[] = "Organization is required.";
            
            if (empty($errors)) {
                $data = [
                    'fullname' => $fullname,
                    'phone' => $phone,
                    'organization' => $organization
                ];
                
                if ($this->userModel->updateProfile($user['user_id'], $data)) {
                    $_SESSION['success'] = "Profile updated successfully!";
                    $_SESSION['fullname'] = $fullname;
                    redirect('/dashboard.php?view=profile');
                } else {
                    $errors[] = "Failed to update profile.";
                }
            }
        }
        
        require_once __DIR__ . '/../views/dashboard/profile.php';
    }
    
    // Show my events
    private function showMyEvents($user) {
        $myEvents = $this->eventModel->getByUserId($user['user_id']);
        
        // Get participant count for each event
        foreach ($myEvents as &$event) {
            $event['participant_count'] = $this->registrationModel->getParticipantCount($event['event_id']);
        }
        
        require_once __DIR__ . '/../views/dashboard/my-events.php';
    }
    
    // Show my registrations
    private function showMyRegistrations($user) {
        $myRegistrations = $this->registrationModel->getUserRegistrations($user['user_id']);
        
        require_once __DIR__ . '/../views/dashboard/my-registrations.php';
    }
    
    public function __destruct() {
        if ($this->conn) {
            $this->conn->close();
        }
    }
}
?>