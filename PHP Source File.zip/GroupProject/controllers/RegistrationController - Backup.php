<?php
// controllers/RegistrationController.php

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../models/Registration.php';
require_once __DIR__ . '/../models/Event.php';

class RegistrationController {
    private $registrationModel;
    private $eventModel;
    private $conn;
    
    public function __construct() {
        $this->conn = getDBConnection();
        $this->registrationModel = new Registration($this->conn);
        $this->eventModel = new Event($this->conn);
    }
    
    // Register for event
    public function register() {
        requireLogin();
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['event_id'])) {
            $eventId = (int)$_POST['event_id'];
            $userId = $_SESSION['user_id'];
            
            // Check if already registered
            if ($this->registrationModel->isRegistered($eventId, $userId)) {
                $_SESSION['error'] = "You are already registered for this event.";
                redirect('/index.php');
            }
            
            // Check if event exists and is active
            $event = $this->eventModel->getById($eventId);
            if (!$event || $event['status'] !== 'active') {
                $_SESSION['error'] = "Event is not available for registration.";
                redirect('/index.php');
            }
            
            // Check registration close date
            if (date('Y-m-d') > $event['registration_close_date']) {
                $_SESSION['error'] = "Registration for this event has closed.";
                redirect('/index.php');
            }
            
            // Check max participants
            if ($event['max_participants']) {
                $currentCount = $this->registrationModel->getParticipantCount($eventId);
                if ($currentCount >= $event['max_participants']) {
                    $_SESSION['error'] = "Event is full. Maximum participants reached.";
                    redirect('/index.php');
                }
            }
            
            // Register
            if ($this->registrationModel->register($eventId, $userId)) {
                $_SESSION['success'] = "Successfully registered for " . $event['event_name'] . "!";
                redirect('/dashboard.php?view=my-registrations');
            } else {
                $_SESSION['error'] = "Registration failed. Please try again.";
                redirect('/index.php');
            }
        } else {
            redirect('/index.php');
        }
    }
    
    // Cancel registration
    public function cancel() {
        requireLogin();
        
        if (isset($_GET['event_id'])) {
            $eventId = (int)$_GET['event_id'];
            $userId = $_SESSION['user_id'];
            
            if ($this->registrationModel->cancel($eventId, $userId)) {
                $_SESSION['success'] = "Registration cancelled successfully.";
            } else {
                $_SESSION['error'] = "Failed to cancel registration.";
            }
            
            redirect('/dashboard.php?view=my-registrations');
        } else {
            redirect('/index.php');
        }
    }
    
    public function __destruct() {
        if ($this->conn) {
            $this->conn->close();
        }
    }
}
?>