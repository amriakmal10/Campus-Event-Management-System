<?php
// controllers/EventController.php

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../models/Event.php';
require_once __DIR__ . '/../models/Registration.php';

class EventController {
    private $eventModel;
    private $registrationModel;
    private $conn;
    
    public function __construct() {
        $this->conn = getDBConnection();
        $this->eventModel = new Event($this->conn);
        $this->registrationModel = new Registration($this->conn);
    }
    
    // Show create event form
    public function showCreate() {
        requireLogin();
        require_once __DIR__ . '/../views/events/create.php';
    }
    
    // Handle create event
    public function create() {
        requireLogin();
        $errors = [];
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $eventName = trim($_POST['event_name'] ?? '');
            $description = trim($_POST['description'] ?? '');
            $organizer = trim($_POST['organizer'] ?? '');
            $contactPerson = trim($_POST['contact_person'] ?? '');
            $contactNo = trim($_POST['contact_no'] ?? '');
            $category = $_POST['category'] ?? '';
            $venue = trim($_POST['venue'] ?? '');
            $eventDate = $_POST['event_date'] ?? '';
            $eventTime = $_POST['event_time'] ?? '';
            $mode = $_POST['mode'] ?? '';
            $registrationCloseDate = $_POST['registration_close_date'] ?? '';
            $maxParticipants = $_POST['max_participants'] ?? null;
            $fee = $_POST['fee'] ?? 0.00;
            $remarks = trim($_POST['remarks'] ?? '');

            // Check for duplicate event names by same user
            $checkStmt = $this->conn->prepare(
                "SELECT event_id FROM events WHERE event_name = ? AND user_id = ?"
            );
            $checkStmt->bind_param("si", $eventName, $_SESSION['user_id']);
            $checkStmt->execute();
            $result = $checkStmt->get_result();

            if ($result->num_rows > 0) {
                $errors[] = "You already have an event with this name. Please use a different name.";
            }
            $checkStmt->close();
            
            // Validation
            if (empty($eventName)) $errors[] = "Event name is required.";
            if (empty($description)) $errors[] = "Description is required.";
            if (empty($organizer)) $errors[] = "Organizer is required.";
            if (empty($category)) $errors[] = "Category is required.";
            if (empty($venue)) $errors[] = "Venue is required.";
            if (empty($eventDate)) $errors[] = "Event date is required.";
            if (empty($eventTime)) $errors[] = "Event time is required.";
            if (empty($mode)) $errors[] = "Mode is required.";
            if (empty($registrationCloseDate)) $errors[] = "Registration close date is required.";
            
            // Date validation
            if (!empty($eventDate) && $eventDate < date('Y-m-d')) {
                $errors[] = "Event date cannot be in the past.";
            }
            
            if (!empty($registrationCloseDate) && !empty($eventDate) && $registrationCloseDate > $eventDate) {
                $errors[] = "Registration close date must be before event date.";
            }
            
            // Handle file upload
            $posterPath = '';
            if (isset($_FILES['poster']) && $_FILES['poster']['error'] === 0) {
                $uploadDir = ROOT_PATH . '/uploads/events/';
                if (!is_dir($uploadDir)) {
                    mkdir($uploadDir, 0777, true);
                }
                
                $allowedTypes = ['jpg', 'jpeg', 'png', 'gif'];
                $fileExt = strtolower(pathinfo($_FILES['poster']['name'], PATHINFO_EXTENSION));
                
                if (!in_array($fileExt, $allowedTypes)) {
                    $errors[] = "Only JPG, JPEG, PNG, and GIF files are allowed.";
                } else {
                    $filename = time() . '_' . basename($_FILES['poster']['name']);
                    $targetPath = $uploadDir . $filename;
                    
                    if (move_uploaded_file($_FILES['poster']['tmp_name'], $targetPath)) {
                        $posterPath = $filename;
                    } else {
                        $errors[] = "Failed to upload poster.";
                    }
                }
            }
            
            if (empty($errors)) {
                $data = [
                    'user_id' => $_SESSION['user_id'],
                    'event_name' => $eventName,
                    'description' => $description,
                    'organizer' => $organizer,
                    'contact_person' => $contactPerson,
                    'contact_no' => $contactNo,
                    'category' => $category,
                    'venue' => $venue,
                    'event_date' => $eventDate,
                    'event_time' => $eventTime,
                    'mode' => $mode,
                    'registration_close_date' => $registrationCloseDate,
                    'max_participants' => $maxParticipants ? (int)$maxParticipants : null,
                    'fee' => (float)$fee,
                    'remarks' => $remarks,
                    'poster_path' => $posterPath
                ];
                
                if ($this->eventModel->create($data)) {
                    $_SESSION['success'] = "Event created successfully!";
                    redirect('/dashboard.php?view=my-events');
                } else {
                    $errors[] = "Failed to create event.";
                }
            }
        }
        
        require_once __DIR__ . '/../views/events/create.php';
    }
    
    // Show edit event form
    public function showEdit($eventId) {
        requireLogin();
        
        $event = $this->eventModel->getById($eventId);
        
        if (!$event) {
            $_SESSION['error'] = "Event not found.";
            redirect('/dashboard.php?view=my-events');
        }
        
        if (!$this->eventModel->isOwner($eventId, $_SESSION['user_id'])) {
            $_SESSION['error'] = "You don't have permission to edit this event.";
            redirect('/dashboard.php?view=my-events');
        }
        
        require_once __DIR__ . '/../views/events/edit.php';
    }
    
    // Handle update event
    public function update($eventId) {
        requireLogin();
        $errors = [];
        
        $event = $this->eventModel->getById($eventId);
        
        if (!$event || !$this->eventModel->isOwner($eventId, $_SESSION['user_id'])) {
            $_SESSION['error'] = "Unauthorized action.";
            redirect('/dashboard.php?view=my-events');
        }
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $eventName = trim($_POST['event_name'] ?? '');
            $description = trim($_POST['description'] ?? '');
            $organizer = trim($_POST['organizer'] ?? '');
            $contactPerson = trim($_POST['contact_person'] ?? '');
            $contactNo = trim($_POST['contact_no'] ?? '');
            $category = $_POST['category'] ?? '';
            $venue = trim($_POST['venue'] ?? '');
            $eventDate = $_POST['event_date'] ?? '';
            $eventTime = $_POST['event_time'] ?? '';
            $mode = $_POST['mode'] ?? '';
            $registrationCloseDate = $_POST['registration_close_date'] ?? '';
            $maxParticipants = $_POST['max_participants'] ?? null;
            $fee = $_POST['fee'] ?? 0.00;
            $remarks = trim($_POST['remarks'] ?? '');
            
            // Validation (same as create)
            if (empty($eventName)) $errors[] = "Event name is required.";
            if (empty($description)) $errors[] = "Description is required.";
            if (empty($organizer)) $errors[] = "Organizer is required.";
            if (empty($category)) $errors[] = "Category is required.";
            if (empty($venue)) $errors[] = "Venue is required.";
            if (empty($eventDate)) $errors[] = "Event date is required.";
            if (empty($eventTime)) $errors[] = "Event time is required.";
            if (empty($mode)) $errors[] = "Mode is required.";
            if (empty($registrationCloseDate)) $errors[] = "Registration close date is required.";
            
            // Handle file upload
            $posterPath = $event['poster_path'];
            if (isset($_FILES['poster']) && $_FILES['poster']['error'] === 0) {
                $uploadDir = ROOT_PATH . '/uploads/events/';
                $allowedTypes = ['jpg', 'jpeg', 'png', 'gif'];
                $fileExt = strtolower(pathinfo($_FILES['poster']['name'], PATHINFO_EXTENSION));
                
                if (in_array($fileExt, $allowedTypes)) {
                    $filename = time() . '_' . basename($_FILES['poster']['name']);
                    $targetPath = $uploadDir . $filename;
                    
                    if (move_uploaded_file($_FILES['poster']['tmp_name'], $targetPath)) {
                        // Delete old poster
                        if (!empty($event['poster_path'])) {
                            $oldPoster = $uploadDir . $event['poster_path'];
                            if (file_exists($oldPoster)) {
                                unlink($oldPoster);
                            }
                        }
                        $posterPath = $filename;
                    }
                }
            }
            
            if (empty($errors)) {
                $data = [
                    'event_name' => $eventName,
                    'description' => $description,
                    'organizer' => $organizer,
                    'contact_person' => $contactPerson,
                    'contact_no' => $contactNo,
                    'category' => $category,
                    'venue' => $venue,
                    'event_date' => $eventDate,
                    'event_time' => $eventTime,
                    'mode' => $mode,
                    'registration_close_date' => $registrationCloseDate,
                    'max_participants' => $maxParticipants ? (int)$maxParticipants : null,
                    'fee' => (float)$fee,
                    'remarks' => $remarks,
                    'poster_path' => $posterPath
                ];
                
                if ($this->eventModel->update($eventId, $data)) {
                    $_SESSION['success'] = "Event updated successfully!";
                    redirect('/dashboard.php?view=my-events');
                } else {
                    $errors[] = "Failed to update event.";
                }
            }
        }
        
        require_once __DIR__ . '/../views/events/edit.php';
    }
    
    // Delete event
    public function delete($eventId) {
        requireLogin();
        
        if (!$this->eventModel->isOwner($eventId, $_SESSION['user_id'])) {
            $_SESSION['error'] = "Unauthorized action.";
            redirect('/dashboard.php?view=my-events');
        }
        
        $event = $this->eventModel->getById($eventId);
        
        // Delete poster file
        if (!empty($event['poster_path'])) {
            $posterPath = ROOT_PATH . '/uploads/events/' . $event['poster_path'];
            if (file_exists($posterPath)) {
                unlink($posterPath);
            }
        }
        
        if ($this->eventModel->delete($eventId)) {
            $_SESSION['success'] = "Event deleted successfully.";
        } else {
            $_SESSION['error'] = "Failed to delete event.";
        }
        
        redirect('/dashboard.php?view=my-events');
    }
    
    // View event details
    public function view($eventId) {
        $event = $this->eventModel->getById($eventId);
        
        if (!$event) {
            $_SESSION['error'] = "Event not found.";
            redirect('/index.php');
        }
        
        $isRegistered = false;
        $participantCount = $this->registrationModel->getParticipantCount($eventId);
        
        if (isLoggedIn()) {
            $isRegistered = $this->registrationModel->isRegistered($eventId, $_SESSION['user_id']);
        }
        
        // IMPORTANT: Pass $conn to view
        $conn = $this->conn;
        
        require_once __DIR__ . '/../views/events/view.php';
    }
    
    public function __destruct() {
        if ($this->conn) {
            $this->conn->close();
        }
    }
}
?>