<?php
// controllers/AdminController.php

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../models/Admin.php';
require_once __DIR__ . '/../models/Event.php';

class AdminController {
    private $adminModel;
    private $eventModel;
    private $conn;
    
    public function __construct() {
        requireLogin();
        requireAdmin(); // New function we'll add to config.php
        
        $this->conn = getDBConnection();
        $this->adminModel = new Admin($this->conn);
        $this->eventModel = new Event($this->conn);
    }
    
    // Admin Dashboard
    public function dashboard() {
        $stats = $this->adminModel->getStatistics();
        require_once __DIR__ . '/../views/admin/dashboard.php';
    }
    
    // ========== USER MANAGEMENT ==========
    
    // List all users
    public function manageUsers() {
        $users = $this->adminModel->getAllUsers();
        require_once __DIR__ . '/../views/admin/users.php';
    }
    
    // Promote user to admin
    public function promoteUser() {
        if (isset($_GET['id'])) {
            $userId = (int)$_GET['id'];
            
            if ($this->adminModel->promoteToAdmin($userId)) {
                $_SESSION['success'] = "User promoted to admin successfully.";
            } else {
                $_SESSION['error'] = "Failed to promote user.";
            }
        }
        
        redirect('/admin-users.php');
    }
    
    // Demote admin to user
    public function demoteUser() {
        if (isset($_GET['id'])) {
            $userId = (int)$_GET['id'];
            
            // Prevent self-demotion
            if ($userId == $_SESSION['user_id']) {
                $_SESSION['error'] = "You cannot demote yourself!";
                redirect('/admin-users.php');
            }
            
            if ($this->adminModel->demoteFromAdmin($userId)) {
                $_SESSION['success'] = "Admin demoted to user successfully.";
            } else {
                $_SESSION['error'] = "Failed to demote admin.";
            }
        }
        
        redirect('/admin-users.php');
    }
    
    // Suspend user
    public function suspendUser() {
        if (isset($_GET['id'])) {
            $userId = (int)$_GET['id'];
            
            // Prevent self-suspension
            if ($userId == $_SESSION['user_id']) {
                $_SESSION['error'] = "You cannot suspend yourself!";
                redirect('/admin-users.php');
            }
            
            if ($this->adminModel->suspendUser($userId)) {
                $_SESSION['success'] = "User suspended successfully.";
            } else {
                $_SESSION['error'] = "Failed to suspend user.";
            }
        }
        
        redirect('/admin-users.php');
    }
    
    // Unsuspend user
    public function unsuspendUser() {
        if (isset($_GET['id'])) {
            $userId = (int)$_GET['id'];
            
            if ($this->adminModel->unsuspendUser($userId)) {
                $_SESSION['success'] = "User unsuspended successfully.";
            } else {
                $_SESSION['error'] = "Failed to unsuspend user.";
            }
        }
        
        redirect('/admin-users.php');
    }
    
    // Delete user
    public function deleteUser() {
        if (isset($_GET['id'])) {
            $userId = (int)$_GET['id'];
            
            // Prevent self-deletion
            if ($userId == $_SESSION['user_id']) {
                $_SESSION['error'] = "You cannot delete yourself!";
                redirect('/admin-users.php');
            }
            
            if ($this->adminModel->deleteUser($userId)) {
                $_SESSION['success'] = "User deleted successfully.";
            } else {
                $_SESSION['error'] = "Failed to delete user.";
            }
        }
        
        redirect('/admin-users.php');
    }
    
    // ========== EVENT MANAGEMENT ==========
    
    // Manage all events
    public function manageEvents() {
        $events = $this->adminModel->getAllEvents();
        require_once __DIR__ . '/../views/admin/events.php';
    }
    
    // Approve event
    public function approveEvent() {
        if (isset($_GET['id'])) {
            $eventId = (int)$_GET['id'];
            
            if ($this->adminModel->approveEvent($eventId)) {
                $_SESSION['success'] = "Event approved successfully.";
            } else {
                $_SESSION['error'] = "Failed to approve event.";
            }
        }
        
        redirect('/admin-events.php');
    }
    
    // Reject event
    public function rejectEvent() {
        if (isset($_GET['id'])) {
            $eventId = (int)$_GET['id'];
            
            if ($this->adminModel->rejectEvent($eventId)) {
                $_SESSION['success'] = "Event rejected.";
            } else {
                $_SESSION['error'] = "Failed to reject event.";
            }
        }
        
        redirect('/admin-events.php');
    }
    
    // Highlight event
    public function highlightEvent() {
        if (isset($_GET['id'])) {
            $eventId = (int)$_GET['id'];
            
            if ($this->adminModel->highlightEvent($eventId)) {
                $_SESSION['success'] = "Event highlighted successfully.";
            } else {
                $_SESSION['error'] = "Failed to highlight event.";
            }
        }
        
        redirect('/admin-events.php');
    }
    
    // Unhighlight event
    public function unhighlightEvent() {
        if (isset($_GET['id'])) {
            $eventId = (int)$_GET['id'];
            
            if ($this->adminModel->unhighlightEvent($eventId)) {
                $_SESSION['success'] = "Event unhighlighted.";
            } else {
                $_SESSION['error'] = "Failed to unhighlight event.";
            }
        }
        
        redirect('/admin-events.php');
    }
    
    // Archive event
    public function archiveEvent() {
        if (isset($_GET['id'])) {
            $eventId = (int)$_GET['id'];
            
            if ($this->adminModel->archiveEvent($eventId)) {
                $_SESSION['success'] = "Event archived successfully.";
            } else {
                $_SESSION['error'] = "Failed to archive event.";
            }
        }
        
        redirect('/admin-events.php');
    }
    
    // Delete event (admin override)
    public function deleteEventAdmin() {
        if (isset($_GET['id'])) {
            $eventId = (int)$_GET['id'];
            
            // Get event details for file deletion
            $event = $this->eventModel->getById($eventId);
            
            // Delete poster file
            if (!empty($event['poster_path'])) {
                $posterPath = ROOT_PATH . '/uploads/events/' . $event['poster_path'];
                if (file_exists($posterPath)) {
                    unlink($posterPath);
                }
            }
            
            if ($this->adminModel->deleteEvent($eventId)) {
                $_SESSION['success'] = "Event deleted successfully.";
            } else {
                $_SESSION['error'] = "Failed to delete event.";
            }
        }
        
        redirect('/admin-events.php');
    }
    
    // ========== STATISTICS ==========
    
    // View statistics
    public function viewStatistics() {
        $stats = $this->adminModel->getStatistics();
        require_once __DIR__ . '/../views/admin/statistics.php';
    }
    
    public function __destruct() {
        if ($this->conn) {
            $this->conn->close();
        }
    }
}
?>