<?php
// controllers/AuthController.php

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../models/User.php';

class AuthController {
    private $userModel;
    private $conn;
    
    public function __construct() {
        $this->conn = getDBConnection();
        $this->userModel = new User($this->conn);
    }
    
    // Show register form
    public function showRegister() {
        $errors = [];
        $values = [];
        require_once __DIR__ . '/../views/auth/register.php';
    }
    
    // Handle registration
    public function register() {
        $errors = [];
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // Validate input
            $category = trim($_POST['category'] ?? '');
            $fullname = trim($_POST['fullname'] ?? '');
            $email = trim($_POST['email'] ?? '');
            $phone = trim($_POST['phone'] ?? '');
            $organization = trim($_POST['organization'] ?? '');
            $password = $_POST['password'] ?? '';
            $confirmPassword = $_POST['confirm_password'] ?? '';
            $recommendEvents = $_POST['recommend_events'] ?? [];
            
            // Validation
            if (empty($category)) {
                $errors[] = "Category is required.";
            }
            
            if (empty($fullname)) {
                $errors[] = "Full name is required.";
            }
            
            if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $errors[] = "Valid email is required.";
            }
            
            if ($this->userModel->emailExists($email)) {
                $errors[] = "Email already registered.";
            }
            
            if (empty($phone)) {
                $errors[] = "Phone number is required.";
            }
            
            if (empty($organization)) {
                $errors[] = "Organization is required.";
            }
            
            if (empty($password) || strlen($password) < 6) {
                $errors[] = "Password must be at least 6 characters.";
            }
            
            if ($password !== $confirmPassword) {
                $errors[] = "Passwords do not match.";
            }
            
            if (empty($recommendEvents)) {
                $errors[] = "Please select at least one event type.";
            }
            
            if (empty($errors)) {
                $data = [
                    'category' => $category,
                    'fullname' => $fullname,
                    'email' => $email,
                    'phone' => $phone,
                    'organization' => $organization,
                    'password' => $password,
                    'recommend_events' => $recommendEvents
                ];
                
                if ($this->userModel->register($data)) {
                    $_SESSION['success'] = "Registration successful! Please login.";
                    redirect('/login.php');
                } else {
                    $errors[] = "Registration failed. Please try again.";
                }
            }
        }
        
        require_once __DIR__ . '/../views/auth/register.php';
    }
    
    // Show login form
    public function showLogin() {
        $errors = [];
        require_once __DIR__ . '/../views/auth/login.php';
    }
    
    // Handle login
    public function login() {
        $errors = [];
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $email = trim($_POST['email'] ?? '');
            $password = $_POST['password'] ?? '';
            
            if (empty($email)) {
                $errors[] = "Email is required.";
            }
            
            if (empty($password)) {
                $errors[] = "Password is required.";
            }
            
            if (empty($errors)) {
                $user = $this->userModel->login($email, $password);
                
                if ($user) {
                    $_SESSION['user_id'] = $user['user_id'];
                    $_SESSION['fullname'] = $user['fullname'];
                    $_SESSION['email'] = $user['email'];
                    $_SESSION['category'] = $user['category'];
                    $_SESSION['success'] = "Welcome back, " . $user['fullname'] . "!";
                    
                    redirect('/dashboard.php');
                } else {
                    $errors[] = "Invalid email or password.";
                }
            }
        }
        
        require_once __DIR__ . '/../views/auth/login.php';
    }
    
    // Logout
    public function logout() {
        session_destroy();
        redirect('/index.php');
    }
    
    public function __destruct() {
        if ($this->conn) {
            $this->conn->close();
        }
    }
}
?>