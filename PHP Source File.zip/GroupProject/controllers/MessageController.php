<?php
// controllers/MessageController.php

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../models/Message.php';
require_once __DIR__ . '/../models/Event.php';
require_once __DIR__ . '/../models/Notification.php';
require_once __DIR__ . '/../models/Registration.php';

class MessageController {
    private $messageModel;
    private $eventModel;
    private $notificationModel;
    private $registrationModel;
    private $conn;
    
    public function __construct() {
        requireLogin();
        $this->conn = getDBConnection();
        $this->messageModel = new Message($this->conn);
        $this->eventModel = new Event($this->conn);
        $this->notificationModel = new Notification($this->conn);
        $this->registrationModel = new Registration($this->conn);
    }
    
    // Show message form
    public function create() {
        if (!isset($_GET['event_id'])) {
            redirect('/dashboard.php?view=my-events');
        }
        
        $eventId = (int)$_GET['event_id'];
        $event = $this->eventModel->getById($eventId);
        
        if (!$event || !$this->eventModel->isOwner($eventId, $_SESSION['user_id'])) {
            $_SESSION['error'] = "Unauthorized action.";
            redirect('/dashboard.php?view=my-events');
        }
        
        $participantCount = $this->registrationModel->getParticipantCount($eventId);
        $errors = [];
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $subject = trim($_POST['subject'] ?? '');
            $message = trim($_POST['message'] ?? '');
            
            if (empty($subject)) {
                $errors[] = "Subject is required.";
            }
            
            if (empty($message)) {
                $errors[] = "Message is required.";
            }
            
            if (empty($errors)) {
                // Send message
                if ($this->messageModel->sendToParticipants($eventId, $_SESSION['user_id'], $subject, $message)) {
                    // Create notifications for all participants
                    $this->notificationModel->notifyEventParticipants(
                        $eventId,
                        'message',
                        "New Message: {$subject}",
                        $message
                    );
                    
                    $_SESSION['success'] = "Message sent to all {$participantCount} participants!";
                    redirect('/event.php?id=' . $eventId);
                } else {
                    $errors[] = "Failed to send message.";
                }
            }
        }
        
        require_once __DIR__ . '/../views/messages/create.php';
    }
    
    // View messages for an event
    public function view() {
        if (!isset($_GET['event_id'])) {
            redirect('/index.php');
        }
        
        $eventId = (int)$_GET['event_id'];
        $event = $this->eventModel->getById($eventId);
        
        if (!$event) {
            $_SESSION['error'] = "Event not found.";
            redirect('/index.php');
        }
        
        // Check if user is owner or participant
        $isOwner = $this->eventModel->isOwner($eventId, $_SESSION['user_id']);
        $isParticipant = $this->registrationModel->isRegistered($eventId, $_SESSION['user_id']);
        
        if (!$isOwner && !$isParticipant) {
            $_SESSION['error'] = "You don't have access to view these messages.";
            redirect('/event.php?id=' . $eventId);
        }
        
        $messages = $this->messageModel->getEventMessages($eventId);
        
        require_once __DIR__ . '/../views/messages/view.php';
    }
    
    public function __destruct() {
        if ($this->conn) {
            $this->conn->close();
        }
    }
}
?>