<?php
// controllers/FeedbackController.php

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../models/Feedback.php';
require_once __DIR__ . '/../models/Event.php';
require_once __DIR__ . '/../models/Registration.php';

class FeedbackController {
    private $feedbackModel;
    private $eventModel;
    private $registrationModel;
    private $conn;
    
    public function __construct() {
        $this->conn = getDBConnection();
        $this->feedbackModel = new Feedback($this->conn);
        $this->eventModel = new Event($this->conn);
        $this->registrationModel = new Registration($this->conn);
    }
    
    // Show feedback form
    public function create() {
        requireLogin();
        
        if (!isset($_GET['event_id'])) {
            $_SESSION['error'] = "Event not found.";
            redirect('/dashboard.php?view=my-registrations');
        }
        
        $eventId = (int)$_GET['event_id'];
        $userId = $_SESSION['user_id'];
        $event = $this->eventModel->getById($eventId);
        
        if (!$event) {
            $_SESSION['error'] = "Event not found.";
            redirect('/dashboard.php?view=my-registrations');
        }
        
        // Check if user attended the event
        if (!$this->registrationModel->isRegistered($eventId, $userId)) {
            $_SESSION['error'] = "You must be registered for this event to give feedback.";
            redirect('/event.php?id=' . $eventId);
        }
        
        // Check if event has passed
        if (date('Y-m-d') <= $event['event_date']) {
            $_SESSION['error'] = "You can only give feedback after the event has ended.";
            redirect('/event.php?id=' . $eventId);
        }
        
        // Check if already gave feedback
        if ($this->feedbackModel->hasFeedback($eventId, $userId)) {
            $_SESSION['error'] = "You have already given feedback for this event.";
            redirect('/event.php?id=' . $eventId);
        }
        
        $errors = [];
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $rating = (int)($_POST['rating'] ?? 0);
            $comment = trim($_POST['comment'] ?? '');
            
            // Validation
            if ($rating < 1 || $rating > 5) {
                $errors[] = "Please select a rating between 1 and 5.";
            }
            
            if (empty($comment)) {
                $errors[] = "Please provide your feedback comment.";
            }
            
            if (empty($errors)) {
                if ($this->feedbackModel->create($eventId, $userId, $rating, $comment)) {
                    $_SESSION['success'] = "Thank you for your feedback!";
                    redirect('/event.php?id=' . $eventId);
                } else {
                    $errors[] = "Failed to submit feedback. Please try again.";
                }
            }
        }
        
        require_once __DIR__ . '/../views/feedback/create.php';
    }
    
    // Show event feedback
    public function view() {
        if (!isset($_GET['event_id'])) {
            redirect('/index.php');
        }
        
        $eventId = (int)$_GET['event_id'];
        $event = $this->eventModel->getById($eventId);
        
        if (!$event) {
            $_SESSION['error'] = "Event not found.";
            redirect('/index.php');
        }
        
        $feedback = $this->feedbackModel->getEventFeedback($eventId);
        $ratingStats = $this->feedbackModel->getAverageRating($eventId);
        $distribution = $this->feedbackModel->getRatingDistribution($eventId);
        
        require_once __DIR__ . '/../views/feedback/view.php';
    }
    
    // Edit feedback
    public function edit() {
        requireLogin();
        
        if (!isset($_GET['id'])) {
            redirect('/dashboard.php?view=my-registrations');
        }
        
        $feedbackId = (int)$_GET['id'];
        $userId = $_SESSION['user_id'];
        
        // Get existing feedback
        $stmt = $this->conn->prepare("SELECT * FROM event_feedback WHERE feedback_id = ? AND user_id = ?");
        $stmt->bind_param("ii", $feedbackId, $userId);
        $stmt->execute();
        $result = $stmt->get_result();
        $existingFeedback = $result->fetch_assoc();
        
        if (!$existingFeedback) {
            $_SESSION['error'] = "Feedback not found.";
            redirect('/dashboard.php?view=my-registrations');
        }
        
        $event = $this->eventModel->getById($existingFeedback['event_id']);
        $errors = [];
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $rating = (int)($_POST['rating'] ?? 0);
            $comment = trim($_POST['comment'] ?? '');
            
            if ($rating < 1 || $rating > 5) {
                $errors[] = "Please select a rating between 1 and 5.";
            }
            
            if (empty($comment)) {
                $errors[] = "Please provide your feedback comment.";
            }
            
            if (empty($errors)) {
                if ($this->feedbackModel->update($feedbackId, $userId, $rating, $comment)) {
                    $_SESSION['success'] = "Feedback updated successfully!";
                    redirect('/event.php?id=' . $existingFeedback['event_id']);
                } else {
                    $errors[] = "Failed to update feedback.";
                }
            }
        }
        
        require_once __DIR__ . '/../views/feedback/edit.php';
    }
    
    // Delete feedback
    public function delete() {
        requireLogin();
        
        if (isset($_GET['id'])) {
            $feedbackId = (int)$_GET['id'];
            $userId = $_SESSION['user_id'];
            
            if ($this->feedbackModel->delete($feedbackId, $userId)) {
                $_SESSION['success'] = "Feedback deleted successfully.";
            } else {
                $_SESSION['error'] = "Failed to delete feedback.";
            }
        }
        
        redirect('/dashboard.php?view=my-registrations');
    }
    
    public function __destruct() {
        if ($this->conn) {
            $this->conn->close();
        }
    }
}
?>