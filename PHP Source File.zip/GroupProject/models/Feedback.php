<?php
// models/Feedback.php

class Feedback {
    private $conn;
    
    public function __construct($dbConnection) {
        $this->conn = $dbConnection;
    }
    
    // Create feedback
    public function create($eventId, $userId, $rating, $comment) {
        $stmt = $this->conn->prepare(
            "INSERT INTO event_feedback (event_id, user_id, rating, comment) 
             VALUES (?, ?, ?, ?)"
        );
        
        $stmt->bind_param("iiis", $eventId, $userId, $rating, $comment);
        return $stmt->execute();
    }
    
    // Update feedback
    public function update($feedbackId, $userId, $rating, $comment) {
        $stmt = $this->conn->prepare(
            "UPDATE event_feedback SET rating = ?, comment = ? 
             WHERE feedback_id = ? AND user_id = ?"
        );
        
        $stmt->bind_param("isii", $rating, $comment, $feedbackId, $userId);
        return $stmt->execute();
    }
    
    // Delete feedback
    public function delete($feedbackId, $userId) {
        $stmt = $this->conn->prepare(
            "DELETE FROM event_feedback WHERE feedback_id = ? AND user_id = ?"
        );
        
        $stmt->bind_param("ii", $feedbackId, $userId);
        return $stmt->execute();
    }
    
    // Get event feedback
    public function getEventFeedback($eventId) {
        $stmt = $this->conn->prepare(
            "SELECT f.*, u.fullname, u.category 
             FROM event_feedback f
             JOIN users u ON f.user_id = u.user_id
             WHERE f.event_id = ?
             ORDER BY f.created_at DESC"
        );
        
        $stmt->bind_param("i", $eventId);
        $stmt->execute();
        $result = $stmt->get_result();
        
        $feedback = [];
        while ($row = $result->fetch_assoc()) {
            $feedback[] = $row;
        }
        
        return $feedback;
    }
    
    // Get user's feedback for an event
    public function getUserFeedback($eventId, $userId) {
        $stmt = $this->conn->prepare(
            "SELECT * FROM event_feedback WHERE event_id = ? AND user_id = ?"
        );
        
        $stmt->bind_param("ii", $eventId, $userId);
        $stmt->execute();
        $result = $stmt->get_result();
        
        return $result->fetch_assoc();
    }
    
    // Check if user has given feedback
    public function hasFeedback($eventId, $userId) {
        $stmt = $this->conn->prepare(
            "SELECT feedback_id FROM event_feedback WHERE event_id = ? AND user_id = ?"
        );
        
        $stmt->bind_param("ii", $eventId, $userId);
        $stmt->execute();
        $result = $stmt->get_result();
        
        return $result->num_rows > 0;
    }
    
    // Get average rating for event
    public function getAverageRating($eventId) {
        $stmt = $this->conn->prepare(
            "SELECT AVG(rating) as avg_rating, COUNT(*) as total_feedback 
             FROM event_feedback WHERE event_id = ?"
        );
        
        $stmt->bind_param("i", $eventId);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();
        
        return [
            'average' => $row['avg_rating'] ? round($row['avg_rating'], 1) : 0,
            'total' => $row['total_feedback']
        ];
    }
    
    // Get rating distribution
    public function getRatingDistribution($eventId) {
        $stmt = $this->conn->prepare(
            "SELECT rating, COUNT(*) as count 
             FROM event_feedback 
             WHERE event_id = ? 
             GROUP BY rating 
             ORDER BY rating DESC"
        );
        
        $stmt->bind_param("i", $eventId);
        $stmt->execute();
        $result = $stmt->get_result();
        
        $distribution = [5 => 0, 4 => 0, 3 => 0, 2 => 0, 1 => 0];
        while ($row = $result->fetch_assoc()) {
            $distribution[$row['rating']] = $row['count'];
        }
        
        return $distribution;
    }
}
?>