<?php
// models/Registration.php

class Registration {
    private $conn;
    
    public function __construct($dbConnection) {
        $this->conn = $dbConnection;
    }
    
    // Register user for event
    public function register($eventId, $userId) {
        $stmt = $this->conn->prepare(
            "INSERT INTO event_registrations (event_id, user_id) VALUES (?, ?)"
        );
        
        $stmt->bind_param("ii", $eventId, $userId);
        return $stmt->execute();
    }
    
    // Cancel registration
    public function cancel($eventId, $userId) {
        $stmt = $this->conn->prepare(
            "DELETE FROM event_registrations WHERE event_id = ? AND user_id = ?"
        );
        
        $stmt->bind_param("ii", $eventId, $userId);
        return $stmt->execute();
    }
    
    // Check if user is registered
    public function isRegistered($eventId, $userId) {
        $stmt = $this->conn->prepare(
            "SELECT registration_id FROM event_registrations WHERE event_id = ? AND user_id = ?"
        );
        
        $stmt->bind_param("ii", $eventId, $userId);
        $stmt->execute();
        $result = $stmt->get_result();
        
        return $result->num_rows > 0;
    }
    
    // Get user's registrations
    public function getUserRegistrations($userId) {
        $stmt = $this->conn->prepare(
            "SELECT er.*, e.event_name, e.event_date, e.event_time, e.venue, e.mode
             FROM event_registrations er
             JOIN events e ON er.event_id = e.event_id
             WHERE er.user_id = ?
             ORDER BY er.registration_date DESC"
        );
        
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $result = $stmt->get_result();
        
        $registrations = [];
        while ($row = $result->fetch_assoc()) {
            $registrations[] = $row;
        }
        
        return $registrations;
    }
    
    // Get event participants
    public function getEventParticipants($eventId) {
        $stmt = $this->conn->prepare(
            "SELECT er.*, u.fullname, u.email, u.phone, u.category
             FROM event_registrations er
             JOIN users u ON er.user_id = u.user_id
             WHERE er.event_id = ?
             ORDER BY er.registration_date DESC"
        );
        
        $stmt->bind_param("i", $eventId);
        $stmt->execute();
        $result = $stmt->get_result();
        
        $participants = [];
        while ($row = $result->fetch_assoc()) {
            $participants[] = $row;
        }
        
        return $participants;
    }
    
    // Get participant count
    public function getParticipantCount($eventId) {
        $stmt = $this->conn->prepare(
            "SELECT COUNT(*) as count FROM event_registrations WHERE event_id = ?"
        );
        
        $stmt->bind_param("i", $eventId);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();
        
        return $row['count'];
    }
}
?>