<?php
// models/Event.php

class Event {
    private $conn;
    
    public function __construct($dbConnection) {
        $this->conn = $dbConnection;
    }
    
    // Get all active events
    public function getAll() {
        $sql = "SELECT e.*, u.fullname as creator_name 
                FROM events e 
                JOIN users u ON e.user_id = u.user_id 
                WHERE e.status = 'active' 
                ORDER BY e.event_date ASC";
        
        $result = $this->conn->query($sql);
        
        $events = [];
        if ($result && $result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $events[] = $row;
            }
        }
        
        return $events;
    }
    
    // Get events by user ID
    public function getByUserId($userId) {
        $stmt = $this->conn->prepare(
            "SELECT * FROM events WHERE user_id = ? ORDER BY event_date DESC"
        );
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $result = $stmt->get_result();
        
        $events = [];
        while ($row = $result->fetch_assoc()) {
            $events[] = $row;
        }
        
        return $events;
    }
    
    // Get event by ID
    public function getById($eventId) {
        $stmt = $this->conn->prepare("SELECT * FROM events WHERE event_id = ?");
        $stmt->bind_param("i", $eventId);
        $stmt->execute();
        $result = $stmt->get_result();
        
        return $result->fetch_assoc();
    }
    
    // Create new event
    public function create($data) {
        $stmt = $this->conn->prepare(
            "INSERT INTO events (user_id, event_name, description, organizer, contact_person, contact_no, 
             category, venue, event_date, event_time, mode, registration_close_date, max_participants, fee, remarks, poster_path) 
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
        );
        
        $stmt->bind_param(
            "isssssssssssidss",
            $data['user_id'],
            $data['event_name'],
            $data['description'],
            $data['organizer'],
            $data['contact_person'],
            $data['contact_no'],
            $data['category'],
            $data['venue'],
            $data['event_date'],
            $data['event_time'],
            $data['mode'],
            $data['registration_close_date'],
            $data['max_participants'],
            $data['fee'],
            $data['remarks'],
            $data['poster_path']
        );
        
        return $stmt->execute();
    }
    
    // Update event
    public function update($eventId, $data) {
        $stmt = $this->conn->prepare(
            "UPDATE events SET event_name=?, description=?, organizer=?, contact_person=?, contact_no=?, 
             category=?, venue=?, event_date=?, event_time=?, mode=?, registration_close_date=?, 
             max_participants=?, fee=?, remarks=?, poster_path=? 
             WHERE event_id=?"
        );
        
        $stmt->bind_param(
            "sssssssssssisssi",
            $data['event_name'],
            $data['description'],
            $data['organizer'],
            $data['contact_person'],
            $data['contact_no'],
            $data['category'],
            $data['venue'],
            $data['event_date'],
            $data['event_time'],
            $data['mode'],
            $data['registration_close_date'],
            $data['max_participants'],
            $data['fee'],
            $data['remarks'],
            $data['poster_path'],
            $eventId
        );
        
        return $stmt->execute();
    }
    
    // Delete event
    public function delete($eventId) {
        $stmt = $this->conn->prepare("DELETE FROM events WHERE event_id = ?");
        $stmt->bind_param("i", $eventId);
        return $stmt->execute();
    }
    
    // Check if user owns event
    public function isOwner($eventId, $userId) {
        $stmt = $this->conn->prepare("SELECT user_id FROM events WHERE event_id = ?");
        $stmt->bind_param("i", $eventId);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            $event = $result->fetch_assoc();
            return $event['user_id'] == $userId;
        }
        
        return false;
    }
}
?>