<?php
// models/Notification.php

class Notification {
    private $conn;
    
    public function __construct($dbConnection) {
        $this->conn = $dbConnection;
    }
    
    // Create notification
    public function create($userId, $eventId, $type, $title, $message) {
        $stmt = $this->conn->prepare(
            "INSERT INTO notifications (user_id, event_id, type, title, message) 
             VALUES (?, ?, ?, ?, ?)"
        );
        
        $stmt->bind_param("iisss", $userId, $eventId, $type, $title, $message);
        return $stmt->execute();
    }
    
    // Get user notifications
    public function getUserNotifications($userId, $limit = null) {
        $sql = "SELECT n.*, e.event_name 
                FROM notifications n
                LEFT JOIN events e ON n.event_id = e.event_id
                WHERE n.user_id = ?
                ORDER BY n.created_at DESC";
        
        if ($limit) {
            $sql .= " LIMIT " . (int)$limit;
        }
        
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $result = $stmt->get_result();
        
        $notifications = [];
        while ($row = $result->fetch_assoc()) {
            $notifications[] = $row;
        }
        
        return $notifications;
    }
    
    // Get unread count
    public function getUnreadCount($userId) {
        $stmt = $this->conn->prepare(
            "SELECT COUNT(*) as count FROM notifications 
             WHERE user_id = ? AND is_read = FALSE"
        );
        
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();
        
        return $row['count'];
    }
    
    // Mark as read
    public function markAsRead($notificationId, $userId) {
        $stmt = $this->conn->prepare(
            "UPDATE notifications SET is_read = TRUE 
             WHERE notification_id = ? AND user_id = ?"
        );
        
        $stmt->bind_param("ii", $notificationId, $userId);
        return $stmt->execute();
    }
    
    // Mark all as read
    public function markAllAsRead($userId) {
        $stmt = $this->conn->prepare(
            "UPDATE notifications SET is_read = TRUE WHERE user_id = ?"
        );
        
        $stmt->bind_param("i", $userId);
        return $stmt->execute();
    }
    
    // Delete notification
    public function delete($notificationId, $userId) {
        $stmt = $this->conn->prepare(
            "DELETE FROM notifications WHERE notification_id = ? AND user_id = ?"
        );
        
        $stmt->bind_param("ii", $notificationId, $userId);
        return $stmt->execute();
    }
    
    // Send notification to all event participants
    public function notifyEventParticipants($eventId, $type, $title, $message) {
        $stmt = $this->conn->prepare(
            "SELECT user_id FROM event_registrations WHERE event_id = ?"
        );
        
        $stmt->bind_param("i", $eventId);
        $stmt->execute();
        $result = $stmt->get_result();
        
        $success = true;
        while ($row = $result->fetch_assoc()) {
            if (!$this->create($row['user_id'], $eventId, $type, $title, $message)) {
                $success = false;
            }
        }
        
        return $success;
    }
    
    // Helper: Send registration confirmation
    public function sendRegistrationConfirmation($userId, $eventId, $eventName) {
        $title = "Registration Confirmed";
        $message = "You have successfully registered for '{$eventName}'. We'll send you reminders as the event approaches.";
        return $this->create($userId, $eventId, 'registration', $title, $message);
    }
    
    // Helper: Send cancellation notification
    public function sendCancellationNotification($userId, $eventId, $eventName) {
        $title = "Registration Cancelled";
        $message = "Your registration for '{$eventName}' has been cancelled.";
        return $this->create($userId, $eventId, 'cancellation', $title, $message);
    }
    
    // Helper: Send event update notification
    public function sendEventUpdateNotification($eventId, $eventName, $updateMessage) {
        $title = "Event Updated: {$eventName}";
        $message = $updateMessage;
        return $this->notifyEventParticipants($eventId, 'update', $title, $message);
    }
    
    // Helper: Send event reminder
    public function sendEventReminder($eventId, $eventName, $eventDate) {
        $title = "Event Reminder: {$eventName}";
        $message = "Reminder: Your event '{$eventName}' is scheduled for {$eventDate}. Don't forget to attend!";
        return $this->notifyEventParticipants($eventId, 'reminder', $title, $message);
    }
}
?>