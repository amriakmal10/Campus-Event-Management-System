<?php
// models/User.php

class User {
    private $conn;
    
    public function __construct($dbConnection) {
        $this->conn = $dbConnection;
    }
    
    // Register new user
    public function register($data) {
        $stmt = $this->conn->prepare(
            "INSERT INTO users (category, fullname, email, phone, organization, password, recommend_events) 
             VALUES (?, ?, ?, ?, ?, ?, ?)"
        );
        
        $hashedPassword = password_hash($data['password'], PASSWORD_DEFAULT);
        $recommendEvents = implode(',', $data['recommend_events']);
        
        $stmt->bind_param(
            "sssssss",
            $data['category'],
            $data['fullname'],
            $data['email'],
            $data['phone'],
            $data['organization'],
            $hashedPassword,
            $recommendEvents
        );
        
        return $stmt->execute();
    }
    
    // Login user
    public function login($email, $password) {
        $stmt = $this->conn->prepare("SELECT * FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 1) {
            $user = $result->fetch_assoc();
            if (password_verify($password, $user['password'])) {
                return $user;
            }
        }
        
        return false;
    }
    
    // Get user by ID
    public function getById($userId) {
        $stmt = $this->conn->prepare("SELECT * FROM users WHERE user_id = ?");
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $result = $stmt->get_result();
        
        return $result->fetch_assoc();
    }
    
    // Update user profile
    public function updateProfile($userId, $data) {
        $stmt = $this->conn->prepare(
            "UPDATE users SET fullname=?, phone=?, organization=? WHERE user_id=?"
        );
        
        $stmt->bind_param(
            "sssi",
            $data['fullname'],
            $data['phone'],
            $data['organization'],
            $userId
        );
        
        return $stmt->execute();
    }
    
    // Check if email exists
    public function emailExists($email) {
        $stmt = $this->conn->prepare("SELECT user_id FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        
        return $result->num_rows > 0;
    }
}
?>