<?php
// models/Message.php

class Message {
    private $conn;
    
    public function __construct($dbConnection) {
        $this->conn = $dbConnection;
    }
    
    // Send message to event participants
    public function sendToParticipants($eventId, $senderId, $subject, $message) {
        $stmt = $this->conn->prepare(
            "INSERT INTO event_messages (event_id, sender_id, subject, message) 
             VALUES (?, ?, ?, ?)"
        );
        
        $stmt->bind_param("iiss", $eventId, $senderId, $subject, $message);
        return $stmt->execute();
    }
    
    // Get messages for an event
    public function getEventMessages($eventId) {
        $stmt = $this->conn->prepare(
            "SELECT m.*, u.fullname as sender_name 
             FROM event_messages m
             JOIN users u ON m.sender_id = u.user_id
             WHERE m.event_id = ?
             ORDER BY m.sent_at DESC"
        );
        
        $stmt->bind_param("i", $eventId);
        $stmt->execute();
        $result = $stmt->get_result();
        
        $messages = [];
        while ($row = $result->fetch_assoc()) {
            $messages[] = $row;
        }
        
        return $messages;
    }
    
    // Get message by ID
    public function getById($messageId) {
        $stmt = $this->conn->prepare(
            "SELECT m.*, u.fullname as sender_name, e.event_name 
             FROM event_messages m
             JOIN users u ON m.sender_id = u.user_id
             JOIN events e ON m.event_id = e.event_id
             WHERE m.message_id = ?"
        );
        
        $stmt->bind_param("i", $messageId);
        $stmt->execute();
        $result = $stmt->get_result();
        
        return $result->fetch_assoc();
    }
    
    // Delete message
    public function delete($messageId, $senderId) {
        $stmt = $this->conn->prepare(
            "DELETE FROM event_messages WHERE message_id = ? AND sender_id = ?"
        );
        
        $stmt->bind_param("ii", $messageId, $senderId);
        return $stmt->execute();
    }
}
?>