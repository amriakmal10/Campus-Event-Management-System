<?php
// models/Admin.php

class Admin {
    private $conn;
    
    public function __construct($dbConnection) {
        $this->conn = $dbConnection;
    }
    
    // ========== USER MANAGEMENT ==========
    
    // Get all users
    public function getAllUsers() {
        $sql = "SELECT user_id, category, fullname, email, phone, organization, 
                is_admin, is_suspended, created_at 
                FROM users ORDER BY created_at DESC";
        $result = $this->conn->query($sql);
        
        $users = [];
        while ($row = $result->fetch_assoc()) {
            $users[] = $row;
        }
        return $users;
    }
    
    // Promote user to admin
    public function promoteToAdmin($userId) {
        $stmt = $this->conn->prepare("UPDATE users SET is_admin = TRUE WHERE user_id = ?");
        $stmt->bind_param("i", $userId);
        return $stmt->execute();
    }
    
    // Demote admin to user
    public function demoteFromAdmin($userId) {
        $stmt = $this->conn->prepare("UPDATE users SET is_admin = FALSE WHERE user_id = ?");
        $stmt->bind_param("i", $userId);
        return $stmt->execute();
    }
    
    // Suspend user
    public function suspendUser($userId) {
        $stmt = $this->conn->prepare("UPDATE users SET is_suspended = TRUE WHERE user_id = ?");
        $stmt->bind_param("i", $userId);
        return $stmt->execute();
    }
    
    // Unsuspend user
    public function unsuspendUser($userId) {
        $stmt = $this->conn->prepare("UPDATE users SET is_suspended = FALSE WHERE user_id = ?");
        $stmt->bind_param("i", $userId);
        return $stmt->execute();
    }
    
    // Delete user
    public function deleteUser($userId) {
        $stmt = $this->conn->prepare("DELETE FROM users WHERE user_id = ?");
        $stmt->bind_param("i", $userId);
        return $stmt->execute();
    }
    
    // ========== EVENT MANAGEMENT ==========
    
    // Get all events (including pending)
    public function getAllEvents() {
        $sql = "SELECT e.*, u.fullname as creator_name,
                (SELECT COUNT(*) FROM event_registrations WHERE event_id = e.event_id) as participant_count
                FROM events e
                JOIN users u ON e.user_id = u.user_id
                ORDER BY e.created_at DESC";
        $result = $this->conn->query($sql);
        
        $events = [];
        while ($row = $result->fetch_assoc()) {
            $events[] = $row;
        }
        return $events;
    }
    
    // Approve event
    public function approveEvent($eventId) {
        $stmt = $this->conn->prepare("UPDATE events SET approval_status = 'approved' WHERE event_id = ?");
        $stmt->bind_param("i", $eventId);
        return $stmt->execute();
    }
    
    // Reject event
    public function rejectEvent($eventId) {
        $stmt = $this->conn->prepare("UPDATE events SET approval_status = 'rejected' WHERE event_id = ?");
        $stmt->bind_param("i", $eventId);
        return $stmt->execute();
    }
    
    // Highlight event
    public function highlightEvent($eventId) {
        $stmt = $this->conn->prepare("UPDATE events SET is_highlighted = TRUE WHERE event_id = ?");
        $stmt->bind_param("i", $eventId);
        return $stmt->execute();
    }
    
    // Unhighlight event
    public function unhighlightEvent($eventId) {
        $stmt = $this->conn->prepare("UPDATE events SET is_highlighted = FALSE WHERE event_id = ?");
        $stmt->bind_param("i", $eventId);
        return $stmt->execute();
    }
    
    // Archive event
    public function archiveEvent($eventId) {
        $stmt = $this->conn->prepare("UPDATE events SET status = 'completed' WHERE event_id = ?");
        $stmt->bind_param("i", $eventId);
        return $stmt->execute();
    }
    
    // Delete event (admin override)
    public function deleteEvent($eventId) {
        $stmt = $this->conn->prepare("DELETE FROM events WHERE event_id = ?");
        $stmt->bind_param("i", $eventId);
        return $stmt->execute();
    }
    
    // ========== STATISTICS ==========
    
    // Get overall statistics
    public function getStatistics() {
        $stats = [];
        
        // Total users
        $result = $this->conn->query("SELECT COUNT(*) as total FROM users");
        $stats['total_users'] = $result->fetch_assoc()['total'];
        
        // Total events
        $result = $this->conn->query("SELECT COUNT(*) as total FROM events");
        $stats['total_events'] = $result->fetch_assoc()['total'];
        
        // Total registrations
        $result = $this->conn->query("SELECT COUNT(*) as total FROM event_registrations");
        $stats['total_registrations'] = $result->fetch_assoc()['total'];
        
        // Events by category
        $result = $this->conn->query("SELECT category, COUNT(*) as count FROM events GROUP BY category");
        $stats['events_by_category'] = [];
        while ($row = $result->fetch_assoc()) {
            $stats['events_by_category'][$row['category']] = $row['count'];
        }
        
        // Users by category
        $result = $this->conn->query("SELECT category, COUNT(*) as count FROM users GROUP BY category");
        $stats['users_by_category'] = [];
        while ($row = $result->fetch_assoc()) {
            $stats['users_by_category'][$row['category']] = $row['count'];
        }
        
        // Recent events
        $result = $this->conn->query("SELECT event_name, event_date, status FROM events ORDER BY created_at DESC LIMIT 5");
        $stats['recent_events'] = [];
        while ($row = $result->fetch_assoc()) {
            $stats['recent_events'][] = $row;
        }
        
        return $stats;
    }
}
?>
